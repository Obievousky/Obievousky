# Phase 0 — Docker validation image

A minimal Docker image that bundles everything needed to run lplex.exe via
Wine and produce a DVD-Video .iso from a folder of compliant audio files.

## Build context layout

The Dockerfile expects the build context to contain these at the root:

```
.
├── docker/
│   ├── Dockerfile          ← (this directory)
│   ├── docker-compose.yml
│   └── .dockerignore
├── lplex-0.3/              ← extracted from lplex-0.3.zip
│   ├── lplex.exe
│   ├── bin/                (dvdauthor.exe, mplex.exe, jpeg2yuv.exe,
│   │                       mpeg2enc.exe, mkisofs.exe [unused], DLLs)
│   ├── data/               (black_NTSC_*.jpg, black_PAL_*.jpg)
│   ├── readme.html
│   └── gpl.txt
└── audio_dvd_burner.py     ← the Phase 1 pipeline script
```

### One-time setup to assemble the build context

From this directory (where this README lives):

```bash
# 1. Copy the Phase 1 pipeline script in
cp /home/z/my-project/download/audio_dvd_burner.py .

# 2. Copy the lplex bundle (already extracted from lplex-0.3.zip) in
cp -r /home/z/my-project/upload/lplex-extract/lplex-0.3 .

# 3. Verify the layout
ls -la lplex-0.3/lplex.exe lplex-0.3/bin/dvdauthor.exe audio_dvd_burner.py
```

## Build and run

```bash
# Build the image
docker build -f docker/Dockerfile -t lean-audio-dvd:phase0 .

# Or use docker-compose (the compose file sets the context correctly):
docker-compose -f docker/docker-compose.yml build
```

### Smoke test (verify all the tools work inside the container)

```bash
# Wine + lplex should print the lplex 0.3 help text
docker run --rm lean-audio-dvd:phase0 \
    wine64 /app/work/lplex/lplex.exe --help

# mkisofs (genisoimage) should print its version
docker run --rm lean-audio-dvd:phase0 mkisofs --version

# xorriso should print its version
docker run --rm lean-audio-dvd:phase0 xorriso --version

# ffprobe should print its version
docker run --rm lean-audio-dvd:phase0 ffprobe -version

# The pipeline script should print --help
docker run --rm lean-audio-dvd:phase0 --help

# Drive status (will report "No optical drives detected" since no drive is
# passed through — this is the drive-agnostic path, expected to work)
docker run --rm lean-audio-dvd:phase0 drive-status --json
```

### Process an album into an ISO

```bash
# Create the volume
docker volume create dvd-data

# Copy an album into the volume (replace /host/path/to/album with your local copy)
docker run --rm \
    -v dvd-data:/data \
    -v /host/path/to/album:/src \
    busybox cp -r /src /data/uploads/MyAlbum

# Dry-run (probes the audio, prints the lplex + xorriso commands, but doesn't
# actually run Wine or build anything — safe first verification step)
docker run --rm -v dvd-data:/app/data lean-audio-dvd:phase0 \
    process /app/data/uploads/MyAlbum --output /app/data/jobs/MyAlbum --dry-run

# Real run (lplex via Wine, then mkisofs for the ISO)
docker run --rm -v dvd-data:/app/data lean-audio-dvd:phase0 \
    process /app/data/uploads/MyAlbum --output /app/data/jobs/MyAlbum

# The .iso will be at /app/data/jobs/MyAlbum/MyAlbum.iso inside the container.
# To copy it out:
docker run --rm \
    -v dvd-data:/data \
    -v /host/path:/out \
    busybox cp /data/jobs/MyAlbum/MyAlbum.iso /out/
```

### Burn to a real DVD-R disc (optional, requires optical drive)

```bash
# Pass through /dev/sr0 and add --burn
docker run --rm \
    --device /dev/sr0 \
    -v dvd-data:/app/data \
    lean-audio-dvd:phase0 \
    process /app/data/uploads/MyAlbum --output /app/data/jobs/MyAlbum --burn

# Or use docker-compose (uncomment the `devices:` section in
# docker-compose.yml first), then:
docker-compose -f docker/docker-compose.yml run --rm audio-dvd-burner \
    process /app/data/uploads/MyAlbum --output /app/data/jobs/MyAlbum --burn
```

## What's in the image

| Component | Version | Purpose |
|---|---|---|
| python:3.12-slim | (Debian bookworm) | Base image — smaller than ubuntu:22.04, Python+pip pre-installed, glibc (Wine works) |
| wine64 | (apt's current) | Runs lplex.exe (a Windows binary) |
| ffmpeg / ffprobe | (apt's current) | Audio probe + transcode for non-compliant files |
| genisoimage | (apt's current) | Provides `mkisofs` with `-dvd-video` + `-udf` for DVD-Video-compliant ISO authoring. lplex's bundled `mkisofs.exe` does NOT work under Wine. |
| xorriso | (apt's current) | Burns the finished .iso to /dev/sr0 via `xorriso -as cdrecord -dao -eject`. Used only when `--burn` is passed AND a drive is detected. |
| eject | (apt's current) | Tray eject for the "remote garage" workflow |
| util-linux (lsblk) | (apt's current) | Optical drive detection |
| python3 | 3.12 (base image) | Runs the Phase 1 pipeline script (pure stdlib) + the Phase 2 FastAPI app |
| lplex-0.3 | 0.3 (bundled) | The audio DVD authoring tool + its bundled dvdauthor/mplex/jpeg2yuv/mpeg2enc binaries + DLLs |

## Key design decisions

1. **lplex stops at VIDEO_TS, we build the ISO ourselves.** lplex's bundled
   `mkisofs.exe` doesn't work under Wine (errors out as "Z:\\app\\work\\lplex\\bin\\mkisofs.exe not supported on this system"). The pipeline runs lplex with `-c dvd` (stop at VIDEO_TS) and then builds the ISO using the native Linux `mkisofs` (genisoimage). This is transparent — the same `process` command produces the final .iso either way.

2. **Always pass absolute paths to lplex.** lplex.exe runs under Wine, which maps Linux root `/` to Windows Z: drive. Relative paths like `toilet2` get interpreted as Windows-style absolute paths from the Z: drive root, i.e., `\toilet2` = `Z:\toilet2` = `/toilet2` (root of the Linux filesystem). The pipeline resolves `--output` and the album dir to absolute paths before invoking lplex.

3. **Drive-agnostic.** No optical drive present? The pipeline still runs to ISO completion; `--burn` is a no-op. This means the same image can run on laptops, headless servers, and burning-equipped servers.

4. **No database, no UI in Phase 0.** Phase 0 is just the bare pipeline. Phase 2 adds FastAPI + flat-file state management; Phase 3 adds Alpine.js + Tailwind single-page UI.

## Troubleshooting

### "lplex produced VIDEO_TS at /app/toilet2/VIDEO_TS but the ISO build failed with: mkisofs exited 5"

You ran with `--output toilet2` from `/app/` and lplex wrote to `/app/toilet2` (correct, post-fix). The mkisofs error is unrelated — check that the VIDEO_TS folder is non-empty:

```bash
docker run --rm -v dvd-data:/app/data lean-audio-dvd:phase0 \
    ls /app/data/jobs/toilet2/VIDEO_TS
```

If empty, lplex didn't actually author anything — re-run with `--log-level DEBUG` and inspect the lplex output for errors.

### "unknown option -- o" from lplex

This was the original spec-template bug (lplex 0.3 has no `-o` flag). The
pipeline now uses `-d` (`--dir`). Make sure you're using the latest
`audio_dvd_burner.py` — check `git log download/audio_dvd_burner.py` or the
worklog at `/home/z/my-project/worklog.md`, Task ID 5.

### "Z:\\app\\work\\lplex\\bin\\mkisofs.exe not supported on this system"

This means the pipeline is using `-c iso` (lplex's default) instead of
`-c dvd` (our default). Make sure you're using the latest
`audio_dvd_burner.py` — Task ID 6 changed the default from `iso` to `dvd`.

### Wine can't open a file with a Unicode character in the name

The pipeline auto-detects non-ASCII filenames (e.g., the U+2010 Unicode
HYPHEN that macOS tools auto-substitute for the ASCII hyphen) and creates a
symlink with a safe ASCII name pointing back at the original. The original
file is never modified. See Task ID 6 in the worklog for details.

### "xorriso : FAILURE : -as mkisofs: Unsupported option '-dvd-video'"

You're running on a system where only `xorriso` is available (no `mkisofs` /
`genisoimage`). The pipeline auto-detects this and falls back to
`xorriso -as mkisofs` WITHOUT `-dvd-video`/`-udf`, with a warning that the
resulting disc may not be sector-aligned for older DVD players. Install
`genisoimage` in the container (already in the Phase 0 Dockerfile) to get
proper DVD-Video compliance. See Task ID 8 in the worklog for the full
background.
