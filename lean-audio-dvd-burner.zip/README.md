# Lean Audio DVD Burner — Phase 1 Deliverable

Phase 1 of the project: the standalone executable Python script that
executes Lplex via Wine, plus a test suite covering all non-Wine paths.

## Files in this directory

| File | Purpose |
|---|---|
| `audio_dvd_burner.py` | The Phase 1 core pipeline script (standalone, no external Python deps). |

Adjacent (outside `download/`):

| Path | Purpose |
|---|---|
| `/home/z/my-project/scripts/test_phase1.py` | 28-case / 84-assertion test suite. |
| `/home/z/my-project/fixtures/` | Generated audio fixtures (compliant + non-compliant WAV/FLAC). |
| `/home/z/my-project/upload/lplex-extract/lplex-0.3/` | Extracted lplex.exe + bundled bin/ + data/ ready to be COPY'd into the Docker image. |
| `/home/z/my-project/worklog.md` | Multi-agent work log (see Task ID 1). |

## Quick start (host, no Wine needed)

```bash
# Probe a single audio file
python3 audio_dvd_burner.py probe /path/to/track.wav

# Show detected optical drives + media status
python3 audio_dvd_burner.py drive-status --json

# Dry-run an album (probes + prints the lplex command, no Wine call)
python3 audio_dvd_burner.py process /path/to/album \
    --output /tmp/out --dry-run \
    --lplex-path /home/z/my-project/upload/lplex-extract/lplex-0.3/lplex.exe
```

## Inside the Docker container (Phase 0+ runtime)

```bash
# Process an album to ISO only (drive-agnostic)
python3 audio_dvd_burner.py process /app/data/uploads/my_album \
    --output /app/data/jobs/my_album

# Process + auto-eject + burn to /dev/sr0 (remote garage workflow)
python3 audio_dvd_burner.py process /app/data/uploads/my_album \
    --output /app/data/jobs/my_album --burn

# Batch-process multiple albums
python3 audio_dvd_burner.py batch \
    /app/data/uploads/album1 /app/data/uploads/album2 \
    --output /app/data/jobs --burn

# Burn an existing ISO
python3 audio_dvd_burner.py burn /app/data/jobs/my_album/my_album.iso \
    --device /dev/sr0 --speed 4
```

## Key design decisions (deviations from spec, all deliberate)

1. **`--name` instead of `--title`**: lplex 0.3 (the binary in the
   uploaded zip) has no `--title` flag — the actual flag is `--name` /
   `-n`. We default to `--name` to match the real lplex CLI. Pass
   `--title-flag title` to revert to the spec template (useful only if
   you ship a different lplex build that supports `--title`).

2. **`--bg-image` instead of `blank_video.m2v` positional**: lplex 0.3
   expects the background image via `-j <preset>` or `-j =<path>`, not
   as a positional. We default to `-j black` (lplex's internal black
   background from `data/black_*.jpg`) and expose `--bg-image FILE`
   for custom backgrounds. The `--blank-video FILE` positional form is
   also supported (prepended as the first positional) for spec
   faithfulness, with a runtime warning.

3. **`--alignment seamless --shift backward` defaults**: matches
   lplex's `lplex_seamless.bat` shipped pattern ("concert" mode,
   lossless/gapless). Override via `--alignment discrete|padded|none`.

4. **Mono is treated as compliant**: the spec says "stereo" but lplex
   supports 1-8 channels. We pass mono (1ch) through untouched and only
   transcode when channels > 2 (downmix to stereo).

5. **`-f` lplex flag is exposed but not used by default**: lplex 0.3's
   `-f` is for extraction output format, not muxing. The spec's Phase 0
   validation task uses `-f 8`; we expose `--lplex-format` for
   compatibility but don't pass it by default.

## Test suite

```bash
cd /home/z/my-project && python3 scripts/test_phase1.py
# Expected: 84 passed, 0 failed
```

Covers: probe correctness on 5 fixture variants, prepare pass-through
vs. transcode (incl. 6ch→stereo downmix), drive detection, drive_status
shape, build_lplex_command fidelity (default template, --title override,
--bg-image override, --blank-video positional, invalid --media /
--alignment rejection), mux dry-run, mux error paths, CLI --help, CLI
probe subcommand, CLI drive-status, CLI process --dry-run.

## What Phase 1 cannot test on the host

These require Wine in the Docker container (Phase 0):

- Actual lplex.exe invocation (no Wine on host).
- 18-byte LPCM header verification.
- End-to-end ISO generation.
- xorriso burn (no optical drive on host).
- eject tray command.

All these code paths are implemented and tested via dry-run /
empty-drive returns, but the real Wine call will be validated in
Phase 0's minimal Docker container.
