"""Pydantic schemas for the Lean Audio DVD Burner FastAPI app.

All request/response models are defined here. The Phase 1 pipeline script
(audio_dvd_burner.py) is imported as a module — we don't re-implement the
pipeline logic here, we just wrap it in a web service.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class JobStatus(str, Enum):
    """Lifecycle states for a processing job.

    The states transition strictly: pending -> running -> (completed | failed).
    A job is 'pending' from creation until the background worker picks it up,
    'running' while the lplex+xorriso pipeline is executing, and finally
    'completed' (ISO produced) or 'failed' (error raised).
    """
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"  # not used yet — reserved for future cancellation


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class ProcessRequest(BaseModel):
    """POST /api/process — start processing a single uploaded album.

    The album must already exist at /app/data/uploads/<album_name>/ (created
    via POST /api/upload or dropped directly into the volume).
    """
    album_name: str = Field(..., description="Subdirectory name under /app/data/uploads/")
    burn: bool = Field(False, description="Burn the resulting ISO to /dev/sr0 if a drive is present")
    auto_eject: bool = Field(True, description="Eject the tray at job start (remote garage workflow)")
    cleanup_intermediate: bool = Field(False, description="Remove _staging_<album> after mux")
    # lplex options (all optional, with sensible defaults from the pipeline)
    media: str = Field("dvd-r", description="lplex -z media target")
    create: str = Field("dvd", description="lplex -c create stage (dvd/iso/lpcm/m2v/mpeg/dvdstyler)")
    alignment: str = Field("seamless", description="lplex -l splice mode")
    shift: str = Field("backward", description="lplex -s shift direction (only with seamless)")
    tv_standard: Optional[str] = Field(None, description="lplex -t (pal/ntsc, auto-detected if unset)")
    bg_preset: str = Field("black", description="lplex -j background preset")


class MultiAlbumRequest(BaseModel):
    """POST /api/process-multi — combine multiple albums into ONE DVD with
    multiple titlesets.

    Each album becomes a separate title on the DVD (navigable via the DVD
    player's next/prev controls). This uses lplex's `ts` (titleset) flag to
    separate albums within a single lplex invocation. All albums share the
    same VIDEO_TS structure and produce a single .iso file.
    """
    album_names: List[str] = Field(..., description="Subdirectory names under /app/data/uploads/ (each becomes one titleset)")
    project_name: Optional[str] = Field(None, description="DVD/project name (defaults to joined album names). Becomes the DVD volume label.")
    burn: bool = Field(False, description="Burn the resulting ISO to /dev/sr0 if a drive is present")
    auto_eject: bool = Field(True, description="Eject the tray at job start (remote garage workflow)")
    cleanup_intermediate: bool = Field(False, description="Remove staging dir after mux")
    media: str = Field("dvd-r", description="lplex -z media target")
    create: str = Field("dvd", description="lplex -c create stage")
    alignment: str = Field("seamless", description="lplex -l splice mode")
    shift: str = Field("backward", description="lplex -s shift direction (only with seamless)")
    tv_standard: Optional[str] = Field(None, description="lplex -t (pal/ntsc, auto-detected if unset)")
    bg_preset: str = Field("black", description="lplex -j background preset")


class BatchRequest(BaseModel):
    """POST /api/batch — start processing multiple albums.

    By default (parallel=True), all jobs start simultaneously — one background
    thread per album. This lets you burn multiple albums at the same time (or
    at least generate their ISOs concurrently). Set parallel=False for
    sequential execution (one at a time), which is useful if the host has
    limited CPU/disk and you want to avoid resource contention.

    The stop_on_error flag only applies to sequential mode (parallel=False);
    in parallel mode all jobs start at once so there's nothing to cancel.
    """
    album_names: List[str] = Field(..., description="Subdirectory names under /app/data/uploads/")
    burn: bool = Field(False)
    auto_eject: bool = Field(True)
    parallel: bool = Field(True, description="Run all jobs in parallel (one thread per album). Set False for sequential.")
    stop_on_error: bool = Field(False, description="Abort the batch on first failure (sequential mode only)")
    cleanup_intermediate: bool = Field(False)
    media: str = Field("dvd-r")
    create: str = Field("dvd")
    alignment: str = Field("seamless")
    shift: str = Field("backward")
    tv_standard: Optional[str] = None
    bg_preset: str = Field("black")


class CleanupRequest(BaseModel):
    """POST /api/cleanup — trigger automatic retention cleanup.

    Removes job folders older than `max_age_hours`. Default 24h per the spec.
    """
    max_age_hours: int = Field(24, ge=1, le=720, description="Remove jobs older than this many hours")


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class JobMeta(BaseModel):
    """The metadata for one job, persisted as meta.json in the job folder.

    Written atomically (write-to-temp + rename) so a crash mid-update never
    leaves a corrupt meta.json.
    """
    job_id: str
    album_name: str
    status: JobStatus = JobStatus.PENDING
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    iso_path: Optional[str] = None
    error: Optional[str] = None
    # The lplex options that were used (for reproducibility / debugging)
    options: dict = Field(default_factory=dict)

    def to_json(self) -> dict:
        """Serialize for meta.json. datetimes become ISO 8601 strings."""
        d = self.model_dump()
        for k in ("created_at", "started_at", "finished_at"):
            if d.get(k) is not None:
                d[k] = d[k].isoformat()
        return d

    @classmethod
    def from_json(cls, d: dict) -> "JobMeta":
        """Deserialize from meta.json. ISO 8601 strings become datetimes."""
        for k in ("created_at", "started_at", "finished_at"):
            v = d.get(k)
            if isinstance(v, str):
                d[k] = datetime.fromisoformat(v)
        return cls(**d)


class JobCreated(BaseModel):
    """Response for POST /api/process and POST /api/batch (per-album)."""
    job_id: str
    album_name: str
    status: JobStatus
    created_at: datetime


class BatchCreated(BaseModel):
    """Response for POST /api/batch."""
    jobs: List[JobCreated]
    total: int


class AlbumInfo(BaseModel):
    """One uploaded album folder, with metadata extracted from audio tags."""
    name: str
    path: str
    file_count: int
    total_size_bytes: int
    # Metadata from ffprobe (album/artist tags); all None if no tags found
    album_title: Optional[str] = None
    artist: Optional[str] = None
    year: Optional[str] = None
    genre: Optional[str] = None
    total_duration_sec: float = 0.0


class AlbumList(BaseModel):
    albums: List[AlbumInfo]


class JobList(BaseModel):
    jobs: List[JobMeta]
    total: int


class DriveStatusResponse(BaseModel):
    drives: List[dict]
    selected_device: str
    status: dict


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    data_dir: str
    jobs_dir: str
    uploads_dir: str
    active_jobs: int


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
