"""FastAPI app for the Lean Audio DVD Burner — Phase 2 backend.

Wraps the Phase 1 pipeline script (audio_dvd_burner.py) in an async web
service with:
  - Multipart file upload for albums
  - Background thread execution of pipeline jobs
  - Flat-file state management in <DATA_ROOT>/_jobs/<job_id>/
  - SSE log streaming for live pipeline/lplex output
  - Manual + automatic retention cleanup
  - Drive-agnostic optical drive status

Per the project spec, no database is used — all state is in flat files
(meta.json + log files) in a Docker volume.

Run:
  uvicorn app.main:app --host 0.0.0.0 --port 8000

Endpoints (all under /api/ except the UI at /):
  GET    /                  → HTML UI (Phase 3 will expand this)
  GET    /api/health        → service health check
  GET    /api/drive-status  → optical drive detection + media status
  GET    /api/albums        → list uploaded albums
  DELETE /api/albums/{name} → delete an uploaded album (refuses if in use)
  POST   /api/upload        → upload album files (multipart)
  POST   /api/process       → start a single-album job
  POST   /api/batch         → start a multi-album batch (sequential jobs)
  GET    /api/jobs          → list all jobs
  GET    /api/jobs/{id}     → get one job's status
  DELETE /api/jobs/{id}     → delete a job (refuses if running)
  GET    /api/jobs/{id}/logs → SSE stream of pipeline + lplex logs
  POST   /api/cleanup       → trigger retention cleanup (default 24h)
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncGenerator, List, Optional

from fastapi import (
    FastAPI,
    File,
    Form,
    HTTPException,
    UploadFile,
    Request,
)
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles

from . import job_manager
from .schemas import (
    AlbumInfo,
    AlbumList,
    BatchCreated,
    BatchRequest,
    CleanupRequest,
    DriveStatusResponse,
    HealthResponse,
    JobCreated,
    JobList,
    JobMeta,
    JobStatus,
    MultiAlbumRequest,
    ProcessRequest,
)

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

# Resolve paths from environment (matches the Phase 1 script's env vars).
# In Docker these are set by the image; in dev they fall back to /app/data
# or whatever DATA_ROOT is set to in the shell.
DATA_ROOT = Path(os.environ.get("DATA_ROOT", "/app/data"))
JOBS_DIR = DATA_ROOT / "_jobs"
UPLOADS_DIR = DATA_ROOT / "uploads"

# Auto-cleanup interval (seconds). 0 = disabled. Default 1 hour.
AUTO_CLEANUP_INTERVAL = int(os.environ.get("AUTO_CLEANUP_INTERVAL_SEC", "3600"))
# Auto-cleanup max age (hours). Default 24.
AUTO_CLEANUP_MAX_AGE_HOURS = int(os.environ.get("AUTO_CLEANUP_MAX_AGE_HOURS", "24"))

# Version reported by /api/health. Bump on breaking changes.
APP_VERSION = "0.2.0-phase2"

app = FastAPI(
    title="Lean Audio DVD Burner",
    description="A minimalist Dockerized pipeline for creating multi-album "
                "24-bit audio DVDs using Wine-wrapped Lplex.",
    version=APP_VERSION,
)

# Serve the static UI (Phase 3 will populate index.html fully; for now it's
# a minimal test page).
_STATIC_DIR = Path(__file__).resolve().parent / "static"
if _STATIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")


@app.on_event("startup")
async def _startup() -> None:
    """Ensure data dirs exist and (optionally) start the auto-cleanup task."""
    job_manager.ensure_dirs()
    if AUTO_CLEANUP_INTERVAL > 0:
        asyncio.create_task(_auto_cleanup_loop())


async def _auto_cleanup_loop() -> None:
    """Background task that periodically removes old completed/failed jobs.

    Runs forever (daemon task). Skips running jobs. Logs deletions to the
    uvicorn console.
    """
    import logging
    log = logging.getLogger("audio_dvd_burner.web.cleanup")
    while True:
        await asyncio.sleep(AUTO_CLEANUP_INTERVAL)
        try:
            deleted = job_manager.cleanup_old_jobs(AUTO_CLEANUP_MAX_AGE_HOURS)
            if deleted:
                log.info(
                    "Auto-cleanup removed %d job(s) older than %dh: %s",
                    len(deleted), AUTO_CLEANUP_MAX_AGE_HOURS, deleted,
                )
        except Exception as exc:  # never let the loop die
            log.exception("Auto-cleanup error: %s", exc)


# ---------------------------------------------------------------------------
# UI route
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def root_ui() -> HTMLResponse:
    """Serve the single-page HTML UI. Phase 3 will flesh this out; for now
    it's a minimal test page that lists albums and jobs via the API.
    """
    index_path = _STATIC_DIR / "index.html"
    if index_path.is_file():
        return HTMLResponse(index_path.read_text(encoding="utf-8"))
    return HTMLResponse(
        "<h1>Lean Audio DVD Burner</h1>"
        "<p>Phase 2 backend is running. UI not found at static/index.html. "
        "Use the API at /api/*.</p>",
        status_code=200,
    )


# ---------------------------------------------------------------------------
# Health & drive status
# ---------------------------------------------------------------------------

@app.get("/api/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Basic health check. Reports the data dir layout and active job count
    so the UI can show a status indicator.
    """
    return HealthResponse(
        status="ok",
        version=APP_VERSION,
        data_dir=str(DATA_ROOT),
        jobs_dir=str(JOBS_DIR),
        uploads_dir=str(UPLOADS_DIR),
        active_jobs=job_manager.active_job_count(),
    )


@app.get("/api/drive-status", response_model=DriveStatusResponse)
async def drive_status() -> DriveStatusResponse:
    """Report optical drive detection and the selected device's media status.

    Drive-agnostic: works on hosts with no optical drive (returns an empty
    drives list and a no-such-device status).
    """
    import sys
    # Make audio_dvd_burner importable
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import audio_dvd_burner as adb

    drives = adb.detect_optical_drives()
    device = adb.DVD_DEVICE
    status = adb.drive_status(device)
    return DriveStatusResponse(
        drives=[d.as_dict() for d in drives],
        selected_device=device,
        status=status,
    )


# ---------------------------------------------------------------------------
# Album management
# ---------------------------------------------------------------------------

@app.get("/api/albums", response_model=AlbumList)
async def list_albums() -> AlbumList:
    """List all uploaded album folders with file counts and total sizes."""
    albums = [AlbumInfo(**a) for a in job_manager.list_albums()]
    return AlbumList(albums=albums)


@app.delete("/api/albums/{name}")
async def delete_album(name: str) -> dict:
    """Delete an uploaded album folder. Refuses (409 Conflict) if any running
    job references the album.
    """
    if not (UPLOADS_DIR / name).is_dir():
        raise HTTPException(404, f"Album not found: {name}")
    ok = job_manager.delete_album(name)
    if not ok:
        raise HTTPException(
            409,
            f"Cannot delete album '{name}': a running job is using it. "
            f"Wait for the job to finish or delete the job first.",
        )
    return {"deleted": name}


@app.post("/api/upload")
async def upload_album(
    album_name: Optional[str] = Form(None, description="Subdirectory name. If omitted, auto-detected from audio tags."),
    files: List[UploadFile] = File(..., description="Audio files (.wav/.flac)"),
) -> dict:
    """Upload audio files as a new album.

    If `album_name` is not provided, the endpoint auto-detects it:
      1. Saves files to a temp directory
      2. Runs ffprobe to extract the album title from the first file's tags
      3. Sanitizes the title and uses it as the folder name
      4. If no album tag found, falls back to "upload_<timestamp>"

    This means the user can just pick files and click upload — no typing needed.

    Filenames are sanitized to safe ASCII (spaces -> underscores, Unicode ->
    underscore) to avoid Wine path issues.
    """
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import audio_dvd_burner as adb

    # If album_name is provided, validate it. If not, we'll auto-detect.
    if album_name:
        if "/" in album_name or ".." in album_name or not album_name.strip():
            raise HTTPException(400, f"Invalid album name: {album_name!r}")
        final_album_name = album_name.strip()
    else:
        # Auto-detect mode: save to a temp dir first, then probe for album tag
        import tempfile
        temp_dir = Path(tempfile.mkdtemp(dir=str(UPLOADS_DIR), prefix="_tmp_"))
        saved = []
        skipped = []
        for f in files:
            if not f.filename:
                continue
            safe_name = adb._sanitize_filename(Path(f.filename).name)
            if Path(safe_name).suffix.lower() not in adb.SUPPORTED_AUDIO_EXT:
                skipped.append({"filename": f.filename, "reason": "not a .wav/.flac file"})
                continue
            out_path = temp_dir / safe_name
            with open(out_path, "wb") as out:
                while chunk := await f.read(1024 * 1024):
                    out.write(chunk)
            saved.append({"filename": safe_name, "original_filename": f.filename,
                          "size_bytes": out_path.stat().st_size})

        if not saved:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise HTTPException(400, "No audio files (.wav/.flac) found in the upload.")

        # Probe the uploaded files for album title metadata
        meta = adb.fetch_album_metadata(temp_dir)
        detected_title = meta.get("album_title")
        if detected_title:
            # Sanitize the title to a safe folder name
            final_album_name = adb._sanitize_iso_filename(detected_title)
        else:
            # Fallback: use timestamp
            from datetime import datetime
            final_album_name = "upload_" + datetime.now().strftime("%Y%m%d_%H%M%S")

        # Move temp dir to final location
        final_dir = UPLOADS_DIR / final_album_name
        if final_dir.exists():
            # Already exists — append a suffix to avoid overwriting
            import uuid
            final_album_name = f"{final_album_name}_{uuid.uuid4().hex[:4]}"
            final_dir = UPLOADS_DIR / final_album_name
        temp_dir.rename(final_dir)

        # Also try to detect the folder name from webkitRelativePath
        # (when the user selects a folder via the folder picker, the
        # filename includes the folder path, e.g. "AlbumName/01_track.flac")
        folder_from_path = None
        for f in files:
            if not f.filename:
                continue
            # webkitRelativePath is in the filename when using webkitdirectory
            parts = f.filename.replace("\\", "/").split("/")
            if len(parts) > 1:
                folder_from_path = parts[0]
                break
        # If we detected a folder name from the path AND no album tag was found,
        # prefer the folder name over the timestamp fallback
        if folder_from_path and not detected_title:
            safe_folder = adb._sanitize_iso_filename(folder_from_path)
            if safe_folder and safe_folder != final_album_name:
                new_dir = UPLOADS_DIR / safe_folder
                if not new_dir.exists():
                    final_dir.rename(new_dir)
                    final_dir = new_dir
                    final_album_name = safe_folder

        return {
            "album_name": final_album_name,
            "album_path": str(final_dir),
            "auto_detected": detected_title is not None,
            "detected_title": detected_title,
            "artist": meta.get("artist"),
            "year": meta.get("year"),
            "saved": saved,
            "skipped": skipped,
            "total_files": len(saved),
        }

    # Explicit album_name mode (original behavior)
    album_dir = UPLOADS_DIR / final_album_name
    album_dir.mkdir(parents=True, exist_ok=True)

    saved = []
    skipped = []
    for f in files:
        if not f.filename:
            continue
        safe_name = adb._sanitize_filename(Path(f.filename).name)
        if Path(safe_name).suffix.lower() not in adb.SUPPORTED_AUDIO_EXT:
            skipped.append({"filename": f.filename, "reason": "not a .wav/.flac file"})
            continue
        out_path = album_dir / safe_name
        with open(out_path, "wb") as out:
            while chunk := await f.read(1024 * 1024):
                out.write(chunk)
        saved.append({"filename": safe_name, "original_filename": f.filename,
                      "size_bytes": out_path.stat().st_size})

    return {
        "album_name": final_album_name,
        "album_path": str(album_dir),
        "auto_detected": False,
        "saved": saved,
        "skipped": skipped,
        "total_files": len(saved),
    }


# ---------------------------------------------------------------------------
# Job management
# ---------------------------------------------------------------------------

@app.post("/api/process", response_model=JobCreated, status_code=201)
async def process(req: ProcessRequest) -> JobCreated:
    """Start processing a single album into an ISO.

    Creates a job with status=pending and returns immediately. The actual
    pipeline runs in a background thread. Poll GET /api/jobs/{id} for status,
    or connect to GET /api/jobs/{id}/logs (SSE) for live log streaming.
    """
    album_dir = UPLOADS_DIR / req.album_name
    if not album_dir.is_dir():
        raise HTTPException(
            404,
            f"Album not found: {req.album_name!r}. Upload it first via "
            f"POST /api/upload, or drop the folder into {UPLOADS_DIR}/.",
        )

    options = {
        "media": req.media,
        "create": req.create,
        "alignment": req.alignment,
        "shift": req.shift,
        "tv_standard": req.tv_standard,
        "bg_preset": req.bg_preset,
    }
    meta = job_manager.create_job(
        album_name=req.album_name,
        options=options,
        burn=req.burn,
        auto_eject=req.auto_eject,
        cleanup_intermediate=req.cleanup_intermediate,
    )
    return JobCreated(
        job_id=meta.job_id,
        album_name=meta.album_name,
        status=meta.status,
        created_at=meta.created_at,
    )


@app.post("/api/process-multi", response_model=JobCreated, status_code=201)
async def process_multi(req: MultiAlbumRequest) -> JobCreated:
    """Combine multiple albums into ONE DVD with multiple titlesets.

    Each album becomes a separate title on the DVD (navigable via the DVD
    player's next/prev controls). Uses lplex's `ts` flag to separate
    titlesets. All albums share one VIDEO_TS structure and produce a single
    .iso file.

    Returns immediately with a job_id. The pipeline runs in a background
    thread. Poll GET /api/jobs/{id} for status, or connect to
    GET /api/jobs/{id}/logs (SSE) for live log streaming.
    """
    if len(req.album_names) < 2:
        raise HTTPException(
            400,
            "Multi-album processing requires at least 2 albums. "
            "Use POST /api/process for a single album.",
        )

    # Validate all albums exist
    missing = [n for n in req.album_names
               if not (UPLOADS_DIR / n).is_dir()]
    if missing:
        raise HTTPException(
            404,
            f"Album(s) not found: {missing}. Upload them first via POST /api/upload.",
        )

    options = {
        "media": req.media,
        "create": req.create,
        "alignment": req.alignment,
        "shift": req.shift,
        "tv_standard": req.tv_standard,
        "bg_preset": req.bg_preset,
    }
    meta = job_manager.create_multi_album_job(
        album_names=req.album_names,
        options=options,
        project_name=req.project_name,
        burn=req.burn,
        auto_eject=req.auto_eject,
        cleanup_intermediate=req.cleanup_intermediate,
    )
    return JobCreated(
        job_id=meta.job_id,
        album_name=meta.album_name,
        status=meta.status,
        created_at=meta.created_at,
    )


@app.post("/api/batch", response_model=BatchCreated, status_code=201)
async def batch(req: BatchRequest) -> BatchCreated:
    """Start a batch of jobs (one per album). By default all jobs run in
    PARALLEL (one thread per album) so you can process multiple albums at
    the same time. Set parallel=False for sequential execution (one at a
    time, useful for hosts with limited CPU/disk).

    Each album gets its own job_id and folder. Returns immediately with
    the list of created job IDs. Connect to GET /api/jobs/{id}/logs (SSE)
    for each job to follow progress.
    """
    # Validate all albums exist before creating any jobs
    missing = [n for n in req.album_names
               if not (UPLOADS_DIR / n).is_dir()]
    if missing:
        raise HTTPException(
            404,
            f"Album(s) not found: {missing}. Upload them first via POST /api/upload.",
        )

    options = {
        "media": req.media,
        "create": req.create,
        "alignment": req.alignment,
        "shift": req.shift,
        "tv_standard": req.tv_standard,
        "bg_preset": req.bg_preset,
    }
    metas = job_manager.create_batch(
        album_names=req.album_names,
        options=options,
        burn=req.burn,
        auto_eject=req.auto_eject,
        parallel=req.parallel,
        stop_on_error=req.stop_on_error,
        cleanup_intermediate=req.cleanup_intermediate,
    )
    return BatchCreated(
        jobs=[
            JobCreated(
                job_id=m.job_id,
                album_name=m.album_name,
                status=m.status,
                created_at=m.created_at,
            ) for m in metas
        ],
        total=len(metas),
    )


@app.get("/api/jobs", response_model=JobList)
async def list_jobs() -> JobList:
    """List all jobs, newest first."""
    jobs = job_manager.list_jobs()
    return JobList(jobs=jobs, total=len(jobs))


@app.get("/api/jobs/{job_id}", response_model=JobMeta)
async def get_job(job_id: str) -> JobMeta:
    """Get one job's status."""
    meta = job_manager.get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job not found: {job_id}")
    return meta


@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str) -> dict:
    """Delete a job folder. Refuses (409 Conflict) if the job is currently
    running. Returns the deleted job_id on success.
    """
    if job_manager.get_job(job_id) is None:
        raise HTTPException(404, f"Job not found: {job_id}")
    ok = job_manager.delete_job(job_id)
    if not ok:
        raise HTTPException(
            409,
            f"Cannot delete job {job_id}: it is currently running. "
            f"Wait for it to finish first.",
        )
    return {"deleted": job_id}


@app.get("/api/jobs/{job_id}/iso")
async def download_job_iso(job_id: str) -> FileResponse:
    """Download the ISO file produced by a completed job.

    Returns the .iso file as a binary download with the correct
    Content-Disposition header. The job must be completed and have an
    iso_path set in its meta.json.
    """
    meta = job_manager.get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job not found: {job_id}")
    if meta.status != JobStatus.COMPLETED:
        raise HTTPException(
            409,
            f"Job {job_id} is not completed (status={meta.status.value}). "
            f"Wait for it to finish before downloading.",
        )
    if not meta.iso_path:
        raise HTTPException(404, f"Job {job_id} has no ISO path set.")
    iso_path = Path(meta.iso_path)
    if not iso_path.is_file():
        raise HTTPException(
            404,
            f"ISO file not found on disk: {iso_path}. "
            f"It may have been deleted manually.",
        )
    # Use the album name (sanitized) as the download filename
    download_name = iso_path.name
    return FileResponse(
        path=str(iso_path),
        media_type="application/octet-stream",
        filename=download_name,
        headers={
            "Content-Disposition": f'attachment; filename="{download_name}"',
        },
    )


# ---------------------------------------------------------------------------
# SSE log streaming
# ---------------------------------------------------------------------------

@app.get("/api/jobs/{job_id}/logs")
async def stream_job_logs(
    job_id: str,
    request: Request,
    poll_interval: float = 0.5,
) -> StreamingResponse:
    """Server-Sent Events stream of pipeline + lplex log lines.

    The client connects with EventSource and receives lines in the form:

        data: {"source": "pipeline", "line": "...", "offsets": {...}}

    The stream stays open until the client disconnects (we poll for the
    disconnect via request.is_disconnected()) AND the job is finished AND
    we've drained all log lines. If the job is still running, the stream
    stays open even if the client disconnects (logs continue to be written
    to disk).

    If the job is already finished when the client connects, the stream
    dumps all existing log lines and then closes (so the client sees the
    complete history).
    """
    meta = job_manager.get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job not found: {job_id}")

    async def event_stream() -> AsyncGenerator[bytes, None]:
        """Yield SSE-formatted events. Tails pipeline.log + lplex.log."""
        offsets: dict = {}
        idle_loops = 0
        max_idle_loops = 4  # 4 * poll_interval = 2s of idleness after job ends

        while True:
            # Check if the client disconnected
            if await request.is_disconnected():
                break

            # Drain any new log lines
            got_lines = False
            for source, line, new_offsets in job_manager.tail_logs(
                job_id, offsets
            ):
                offsets = new_offsets
                payload = {"source": source, "line": line}
                yield f"data: {json.dumps(payload)}\n\n".encode("utf-8")
                got_lines = True

            if got_lines:
                idle_loops = 0
                continue

            # No new lines. Check if the job is finished.
            current_meta = job_manager.get_job(job_id)
            if current_meta and current_meta.status in (
                JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED
            ):
                idle_loops += 1
                if idle_loops >= max_idle_loops:
                    # Send a final event with the job status so the client
                    # knows the stream is closing because the job finished.
                    final = {
                        "source": "system",
                        "line": f"[job {current_meta.status.value}] "
                                f"stream closing",
                        "status": current_meta.status.value,
                    }
                    yield f"data: {json.dumps(final)}\n\n".encode("utf-8")
                    break

            await asyncio.sleep(poll_interval)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # disable nginx buffering
        },
    )


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

@app.post("/api/cleanup")
async def cleanup(req: CleanupRequest) -> dict:
    """Trigger manual retention cleanup. Removes job folders older than
    max_age_hours (default 24). Running jobs are always preserved.

    Returns the list of deleted job_ids.
    """
    deleted = job_manager.cleanup_old_jobs(req.max_age_hours)
    return {
        "deleted": deleted,
        "count": len(deleted),
        "max_age_hours": req.max_age_hours,
    }


# ---------------------------------------------------------------------------
# Run as: python -m app.main  (dev convenience; uvicorn is the normal way)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "8000")),
        reload=False,
        log_level=os.environ.get("LOG_LEVEL", "info"),
    )
