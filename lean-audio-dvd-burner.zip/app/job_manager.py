"""Flat-file state management for the Lean Audio DVD Burner.

Per the project spec: "Flat-file storage in Docker volume; no database. Job
logs and metadata stored as text files in _jobs/ directory."

Layout under <DATA_ROOT>/_jobs/:

    _jobs/
    ├── <job_id>/
    │   ├── meta.json         (job metadata, atomically written)
    │   ├── pipeline.log      (Python pipeline log: probe, prepare, mux, burn)
    │   ├── lplex.log         (lplex.exe stdout+stderr, captured for the web UI)
    │   ├── output/           (ISO + lplex intermediates + VIDEO_TS)
    │   │   └── <album_name>.iso
    │   └── staging/          (transcoded audio + unicode symlinks)

Each job runs in a background thread (the pipeline is sync — subprocess.run
blocks — so we can't run it on the asyncio event loop directly). The thread:
  1. Updates meta.json: status=running, started_at=now
  2. Configures Python logging to write to pipeline.log
  3. Calls audio_dvd_burner.process_album() with log_file=<lplex.log path>
  4. On success: updates meta.json: status=completed, iso_path, finished_at
  5. On failure: updates meta.json: status=failed, error, finished_at

SSE log streaming (in main.py) tails pipeline.log + lplex.log and streams
new lines to connected clients.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Import the Phase 1 pipeline. The script lives at /app/audio_dvd_burner.py
# in the container, or alongside the app/ package in dev. We add the parent
# dir to sys.path so `import audio_dvd_burner` works in both layouts.
import sys
_APP_DIR = Path(__file__).resolve().parent
_PARENT_DIR = _APP_DIR.parent
if str(_PARENT_DIR) not in sys.path:
    sys.path.insert(0, str(_PARENT_DIR))

import audio_dvd_burner as adb  # noqa: E402

from .schemas import JobMeta, JobStatus

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Allow environment overrides so the app can run in Docker, in dev, or in
# tests with a temp data dir.
DATA_ROOT = Path(os.environ.get("DATA_ROOT", "/app/data"))
JOBS_DIR = DATA_ROOT / "_jobs"
UPLOADS_DIR = DATA_ROOT / "uploads"

# Lock for meta.json writes (atomic within a process; the rename to temp+rename
# handles cross-process safety, but the in-memory dict cache needs a lock).
_meta_lock = threading.Lock()

# Track running jobs so we can refuse to delete them and report active count.
# Keyed by job_id, value is the threading.Thread object.
_running_threads: Dict[str, threading.Thread] = {}


# ---------------------------------------------------------------------------
# Directory setup
# ---------------------------------------------------------------------------

def ensure_dirs() -> None:
    """Create the data dirs on startup. Idempotent."""
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)


def job_dir(job_id: str) -> Path:
    """Return the directory path for one job."""
    return JOBS_DIR / job_id


# ---------------------------------------------------------------------------
# Meta.json read/write (atomic)
# ---------------------------------------------------------------------------

def _meta_path(job_id: str) -> Path:
    return job_dir(job_id) / "meta.json"


def write_meta(meta: JobMeta) -> None:
    """Write meta.json atomically (write-to-temp + rename).

    Atomic writes prevent a crash mid-update from leaving a corrupt file
    that would break job listing on the next startup.
    """
    path = _meta_path(meta.job_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    with _meta_lock:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(meta.to_json(), f, indent=2, default=str)
        # os.rename is atomic on the same filesystem.
        os.replace(tmp, path)


def read_meta(job_id: str) -> Optional[JobMeta]:
    """Read meta.json for one job. Returns None if the job doesn't exist
    or the file is corrupt."""
    path = _meta_path(job_id)
    if not path.is_file():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return JobMeta.from_json(json.load(f))
    except (json.JSONDecodeError, KeyError, ValueError) as exc:
        # Corrupt meta.json — log and treat as not found
        logging.getLogger("audio_dvd_burner.web").error(
            "Corrupt meta.json for job %s: %s", job_id, exc
        )
        return None


def update_meta(job_id: str, **updates: Any) -> Optional[JobMeta]:
    """Atomically update one or more fields on an existing job's meta.

    Returns the updated JobMeta, or None if the job doesn't exist.
    """
    meta = read_meta(job_id)
    if meta is None:
        return None
    for k, v in updates.items():
        if hasattr(meta, k):
            setattr(meta, k, v)
    write_meta(meta)
    return meta


# ---------------------------------------------------------------------------
# Job lifecycle
# ---------------------------------------------------------------------------

def list_jobs() -> List[JobMeta]:
    """List all jobs, sorted by created_at descending (newest first)."""
    if not JOBS_DIR.exists():
        return []
    jobs: List[JobMeta] = []
    for entry in JOBS_DIR.iterdir():
        if not entry.is_dir():
            continue
        meta = read_meta(entry.name)
        if meta is not None:
            jobs.append(meta)
    jobs.sort(key=lambda m: m.created_at, reverse=True)
    return jobs


def get_job(job_id: str) -> Optional[JobMeta]:
    """Get one job's metadata. Returns None if not found."""
    return read_meta(job_id)


def delete_job(job_id: str) -> bool:
    """Delete a job folder. Refuses if the job is currently running.

    Returns True on success, False if the job doesn't exist or is running.
    """
    if job_id in _running_threads and _running_threads[job_id].is_alive():
        return False
    jd = job_dir(job_id)
    if not jd.exists():
        return False
    shutil.rmtree(jd, ignore_errors=True)
    _running_threads.pop(job_id, None)
    return True


def active_job_count() -> int:
    """Count jobs whose background thread is still alive."""
    return sum(
        1 for t in _running_threads.values() if t.is_alive()
    )


# ---------------------------------------------------------------------------
# Job execution (background thread)
# ---------------------------------------------------------------------------

def _job_worker(
    job_id: str,
    album_name: str,
    options: dict,
    log_file: Optional[Path],
    burn: bool,
    auto_eject: bool,
    cleanup_intermediate: bool,
) -> None:
    """The background-thread worker. Runs the Phase 1 pipeline, captures
    lplex output to log_file, and updates meta.json at each lifecycle stage.
    """
    # Use a job-specific logger that writes to pipeline.log
    job_logger = logging.getLogger(f"audio_dvd_burner.web.job.{job_id}")
    job_logger.setLevel(logging.INFO)
    # Don't propagate to root (avoids double-logging to the uvicorn console)
    job_logger.propagate = False

    pipeline_log_path = job_dir(job_id) / "pipeline.log"
    file_handler = logging.FileHandler(pipeline_log_path, encoding="utf-8")
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)-7s %(message)s")
    )
    job_logger.addHandler(file_handler)

    # Also redirect the adb module's log to this file (so probe/prepare/mux
    # log lines end up in pipeline.log alongside the web layer's own lines).
    adb_log_handler = logging.FileHandler(pipeline_log_path, encoding="utf-8")
    adb_log_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)-7s %(message)s")
    )
    adb_logger = logging.getLogger("audio_dvd_burner")
    # Save the existing level so we can restore it
    adb_orig_level = adb_logger.level
    adb_logger.addHandler(adb_log_handler)

    try:
        # Mark as running
        update_meta(
            job_id,
            status=JobStatus.RUNNING,
            started_at=datetime.now(timezone.utc),
        )
        job_logger.info("=== Job %s started for album '%s' ===", job_id, album_name)
        job_logger.info("Options: %s", options)

        album_dir = UPLOADS_DIR / album_name
        if not album_dir.is_dir():
            raise FileNotFoundError(f"Album directory not found: {album_dir}")

        output_dir = job_dir(job_id) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Build lplex kwargs from the options dict
        lplex_kwargs = dict(
            media=options.get("media", "dvd-r"),
            create=options.get("create", "dvd"),
            alignment=options.get("alignment", "seamless"),
            shift=options.get("shift", "backward"),
            tv_standard=options.get("tv_standard"),
            bg_preset=options.get("bg_preset", "black"),
            verbose=True,  # always verbose in the web app for better debugging
        )

        iso_path = adb.process_album(
            album_dir=album_dir,
            output_dir=output_dir,
            burn=burn,
            auto_eject=auto_eject,
            cleanup_intermediate=cleanup_intermediate,
            dry_run=False,
            log_file=log_file,  # lplex output -> <job_dir>/lplex.log
            **lplex_kwargs,
        )

        update_meta(
            job_id,
            status=JobStatus.COMPLETED,
            iso_path=str(iso_path),
            finished_at=datetime.now(timezone.utc),
        )
        job_logger.info("=== Job %s completed: %s ===", job_id, iso_path)

    except adb.PipelineError as exc:
        update_meta(
            job_id,
            status=JobStatus.FAILED,
            error=str(exc),
            finished_at=datetime.now(timezone.utc),
        )
        job_logger.error("Job %s failed (PipelineError): %s", job_id, exc)
    except Exception as exc:
        # Catch-all for unexpected errors (FileNotFoundError, OSError, etc.)
        update_meta(
            job_id,
            status=JobStatus.FAILED,
            error=f"{type(exc).__name__}: {exc}",
            finished_at=datetime.now(timezone.utc),
        )
        job_logger.exception("Job %s failed (unexpected): %s", job_id, exc)
    finally:
        job_logger.removeHandler(file_handler)
        file_handler.close()
        adb_logger.removeHandler(adb_log_handler)
        adb_log_handler.close()
        adb_logger.setLevel(adb_orig_level)
        _running_threads.pop(job_id, None)


def create_job(
    album_name: str,
    options: dict,
    burn: bool = False,
    auto_eject: bool = True,
    cleanup_intermediate: bool = False,
) -> JobMeta:
    """Create a new job and start its background worker thread.

    Returns the initial JobMeta (status=pending). The worker thread updates
    the meta as it progresses.
    """
    ensure_dirs()
    job_id = uuid.uuid4().hex[:12]  # short, URL-safe
    jd = job_dir(job_id)
    jd.mkdir(parents=True, exist_ok=True)

    meta = JobMeta(
        job_id=job_id,
        album_name=album_name,
        status=JobStatus.PENDING,
        options=options,
    )
    write_meta(meta)

    # lplex output goes to <job_dir>/lplex.log (captured, not passthrough)
    log_file = jd / "lplex.log"

    # Start the worker thread. Daemon=True so it doesn't block process exit
    # (important for tests and for graceful container shutdown).
    thread = threading.Thread(
        target=_job_worker,
        args=(job_id, album_name, options, log_file,
              burn, auto_eject, cleanup_intermediate),
        daemon=True,
        name=f"job-{job_id}",
    )
    _running_threads[job_id] = thread
    thread.start()
    return meta


def create_multi_album_job(
    album_names: List[str],
    options: dict,
    project_name: Optional[str] = None,
    burn: bool = False,
    auto_eject: bool = True,
    cleanup_intermediate: bool = False,
) -> JobMeta:
    """Create a job that combines multiple albums into ONE DVD with multiple
    titlesets. Each album becomes a separate title on the DVD.

    Uses adb.process_multi_album() which inserts lplex's `ts` flag between
    albums so they become separate titlesets in a single VIDEO_TS structure.
    """
    ensure_dirs()
    job_id = uuid.uuid4().hex[:12]
    jd = job_dir(job_id)
    jd.mkdir(parents=True, exist_ok=True)

    # The album_name field stores the project name (what the DVD will be called)
    display_name = project_name or " + ".join(album_names)
    meta = JobMeta(
        job_id=job_id,
        album_name=display_name,
        status=JobStatus.PENDING,
        options={**options, "album_names": album_names, "project_name": project_name},
    )
    write_meta(meta)

    log_file = jd / "lplex.log"

    def _multi_album_worker():
        """Worker thread for multi-album processing."""
        job_logger = logging.getLogger(f"audio_dvd_burner.web.job.{job_id}")
        job_logger.setLevel(logging.INFO)
        job_logger.propagate = False
        pipeline_log_path = job_dir(job_id) / "pipeline.log"
        file_handler = logging.FileHandler(pipeline_log_path, encoding="utf-8")
        file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s"))
        job_logger.addHandler(file_handler)
        adb_log_handler = logging.FileHandler(pipeline_log_path, encoding="utf-8")
        adb_log_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s"))
        adb_logger = logging.getLogger("audio_dvd_burner")
        adb_orig_level = adb_logger.level
        adb_logger.addHandler(adb_log_handler)

        try:
            update_meta(job_id, status=JobStatus.RUNNING,
                        started_at=datetime.now(timezone.utc))
            job_logger.info("=== Multi-album job %s started: %s ===",
                            job_id, display_name)
            job_logger.info("Albums: %s", album_names)
            job_logger.info("Options: %s", options)

            album_dirs = [UPLOADS_DIR / n for n in album_names]
            for d in album_dirs:
                if not d.is_dir():
                    raise FileNotFoundError(f"Album directory not found: {d}")

            output_dir = job_dir(job_id) / "output"
            output_dir.mkdir(parents=True, exist_ok=True)

            lplex_kwargs = dict(
                media=options.get("media", "dvd-r"),
                create=options.get("create", "dvd"),
                alignment=options.get("alignment", "seamless"),
                shift=options.get("shift", "backward"),
                tv_standard=options.get("tv_standard"),
                bg_preset=options.get("bg_preset", "black"),
                verbose=True,  # always verbose in the web app for better debugging
            )

            iso_path = adb.process_multi_album(
                album_dirs=album_dirs,
                output_dir=output_dir,
                project_name=project_name,
                burn=burn,
                auto_eject=auto_eject,
                cleanup_intermediate=cleanup_intermediate,
                dry_run=False,
                log_file=log_file,
                **lplex_kwargs,
            )

            update_meta(job_id, status=JobStatus.COMPLETED,
                        iso_path=str(iso_path),
                        finished_at=datetime.now(timezone.utc))
            job_logger.info("=== Multi-album job %s completed: %s ===",
                            job_id, iso_path)

        except adb.PipelineError as exc:
            update_meta(job_id, status=JobStatus.FAILED, error=str(exc),
                        finished_at=datetime.now(timezone.utc))
            job_logger.error("Multi-album job %s failed: %s", job_id, exc)
        except Exception as exc:
            update_meta(job_id, status=JobStatus.FAILED,
                        error=f"{type(exc).__name__}: {exc}",
                        finished_at=datetime.now(timezone.utc))
            job_logger.exception("Multi-album job %s failed: %s", job_id, exc)
        finally:
            job_logger.removeHandler(file_handler)
            file_handler.close()
            adb_logger.removeHandler(adb_log_handler)
            adb_log_handler.close()
            adb_logger.setLevel(adb_orig_level)
            _running_threads.pop(job_id, None)

    thread = threading.Thread(target=_multi_album_worker, daemon=True,
                               name=f"job-{job_id}")
    _running_threads[job_id] = thread
    thread.start()
    return meta


def create_batch(
    album_names: List[str],
    options: dict,
    burn: bool = False,
    auto_eject: bool = True,
    stop_on_error: bool = False,
    cleanup_intermediate: bool = False,
    parallel: bool = True,
) -> List[JobMeta]:
    """Create jobs for multiple albums and start them all immediately.

    By default (parallel=True), all jobs start in PARALLEL — one daemon thread
    per album. This is the user's requested behavior: "burn multiple albums at
    the same time". Each job has its own output dir and staging dir, so they
    don't interfere with each other. Resource contention (CPU, disk I/O) is
    the user's responsibility — if the host can't handle N concurrent lplex
    runs, pass parallel=False for sequential execution.

    With parallel=False, jobs run sequentially (one at a time) via a single
    orchestrator thread. The stop_on_error flag only applies to sequential
    mode (in parallel mode, all jobs start simultaneously so there's nothing
    to cancel).

    Each album gets its own job folder + meta.json + logs, so they're
    individually trackable and deletable via the same /api/jobs endpoints.
    """
    ensure_dirs()
    metas: List[JobMeta] = []
    job_specs: List[tuple] = []  # (job_id, album_name, log_file)

    for album_name in album_names:
        job_id = uuid.uuid4().hex[:12]
        jd = job_dir(job_id)
        jd.mkdir(parents=True, exist_ok=True)
        meta = JobMeta(
            job_id=job_id,
            album_name=album_name,
            status=JobStatus.PENDING,
            options=options,
        )
        write_meta(meta)
        metas.append(meta)
        job_specs.append((job_id, album_name, jd / "lplex.log"))

    if parallel:
        # PARALLEL: start one thread per album. Each _job_worker registers
        # itself in _running_threads, so active_job_count() and delete-safety
        # checks work the same as for single jobs.
        for job_id, album_name, log_file in job_specs:
            thread = threading.Thread(
                target=_job_worker,
                args=(job_id, album_name, options, log_file,
                      burn, auto_eject, cleanup_intermediate),
                daemon=True,
                name=f"job-{job_id}",
            )
            _running_threads[job_id] = thread
            thread.start()
    else:
        # SEQUENTIAL: one orchestrator thread runs all jobs one-by-one.
        # The stop_on_error flag only makes sense in this mode.
        def _batch_orchestrator() -> None:
            for job_id, album_name, log_file in job_specs:
                # Skip if the job was deleted while pending
                if read_meta(job_id) is None:
                    continue
                # Run the worker synchronously in this thread
                _job_worker(
                    job_id, album_name, options, log_file,
                    burn=burn, auto_eject=auto_eject,
                    cleanup_intermediate=cleanup_intermediate,
                )
                # Check if the job failed and stop_on_error is set
                if stop_on_error:
                    meta = read_meta(job_id)
                    if meta and meta.status == JobStatus.FAILED:
                        # Mark remaining jobs as cancelled
                        for jid, _, _ in job_specs:
                            m = read_meta(jid)
                            if m and m.status == JobStatus.PENDING:
                                update_meta(
                                    jid,
                                    status=JobStatus.CANCELLED,
                                    error="Batch aborted due to prior failure",
                                    finished_at=datetime.now(timezone.utc),
                                )
                        break

        thread = threading.Thread(target=_batch_orchestrator, daemon=True,
                                   name=f"batch-{metas[0].job_id if metas else 'empty'}")
        # Don't add to _running_threads (the individual job workers do that)
        thread.start()

    return metas


# ---------------------------------------------------------------------------
# Album management (uploads)
# ---------------------------------------------------------------------------

def list_albums() -> List[dict]:
    """List uploaded album folders with file counts, total sizes, and metadata
    extracted from audio file tags (album title, artist, year, genre, duration).
    """
    if not UPLOADS_DIR.exists():
        return []
    albums = []
    for entry in sorted(UPLOADS_DIR.iterdir()):
        if not entry.is_dir():
            continue
        file_count = 0
        total_size = 0
        for f in entry.iterdir():
            if f.is_file():
                file_count += 1
                total_size += f.stat().st_size
        # Fetch metadata from audio tags via ffprobe
        meta = adb.fetch_album_metadata(entry)
        albums.append({
            "name": entry.name,
            "path": str(entry),
            "file_count": file_count,
            "total_size_bytes": total_size,
            "album_title": meta.get("album_title"),
            "artist": meta.get("artist"),
            "year": meta.get("year"),
            "genre": meta.get("genre"),
            "total_duration_sec": meta.get("total_duration_sec", 0.0),
        })
    return albums


def delete_album(name: str) -> bool:
    """Delete an uploaded album folder. Refuses if any running job references
    the album.
    """
    # Safety: refuse if a running job uses this album
    for job_id, thread in _running_threads.items():
        if not thread.is_alive():
            continue
        meta = read_meta(job_id)
        if meta and meta.album_name == name:
            return False
    album_path = UPLOADS_DIR / name
    if not album_path.is_dir():
        return False
    shutil.rmtree(album_path, ignore_errors=True)
    return True


# ---------------------------------------------------------------------------
# Retention cleanup
# ---------------------------------------------------------------------------

def cleanup_old_jobs(max_age_hours: int = 24) -> List[str]:
    """Remove job folders older than max_age_hours. Returns the list of
    deleted job_ids. Running jobs are always preserved.

    The age is computed from the latest mtime of the directory AND its
    meta.json file (whichever is newer). This ensures that a job whose
    meta.json was just updated (e.g. status changed to completed) isn't
    immediately considered "old" just because the directory mtime lags.
    """
    if not JOBS_DIR.exists():
        return []
    cutoff = time.time() - (max_age_hours * 3600)
    deleted: List[str] = []
    for entry in JOBS_DIR.iterdir():
        if not entry.is_dir():
            continue
        # Skip running jobs
        job_id = entry.name
        if job_id in _running_threads and _running_threads[job_id].is_alive():
            continue
        # Compute age from the latest of: directory mtime, meta.json mtime.
        # If meta.json was recently written (e.g. status change), that
        # timestamp wins, so a recently-finished job isn't immediately eligible.
        try:
            dir_mtime = entry.stat().st_mtime
        except OSError:
            continue
        meta_path = entry / "meta.json"
        meta_mtime = 0
        if meta_path.is_file():
            try:
                meta_mtime = meta_path.stat().st_mtime
            except OSError:
                pass
        effective_mtime = max(dir_mtime, meta_mtime)
        if effective_mtime < cutoff:
            shutil.rmtree(entry, ignore_errors=True)
            _running_threads.pop(job_id, None)
            deleted.append(job_id)
    return deleted


# ---------------------------------------------------------------------------
# Log tailing (for SSE streaming)
# ---------------------------------------------------------------------------

def tail_logs(job_id: str, since_pos: int = 0):
    """Generator that yields (source, line) tuples for new log lines.

    Reads from pipeline.log and lplex.log concurrently. Blocks for up to
    `poll_interval` seconds waiting for new lines, then yields whatever it
    has. The caller (SSE endpoint) decides when to stop.

    `since_pos` is a dict of {filename: byte_offset} — used to resume from
    where the previous call left off. The caller should maintain this dict
    across calls for a given SSE connection.
    """
    jd = job_dir(job_id)
    pipeline_log = jd / "pipeline.log"
    lplex_log = jd / "lplex.log"

    # Track byte offsets for each file
    offsets: Dict[str, int] = {}
    if isinstance(since_pos, dict):
        offsets = dict(since_pos)

    for name, path in [("pipeline", pipeline_log), ("lplex", lplex_log)]:
        if not path.is_file():
            offsets[name] = 0
            continue
        if name not in offsets:
            offsets[name] = 0
        with open(path, "rb") as f:
            f.seek(offsets[name])
            for raw in f:
                # Decode defensively — lplex may emit some odd bytes
                line = raw.decode("utf-8", errors="replace").rstrip("\n")
                yield (name, line, offsets)
                # Update offset after yielding so the caller can checkpoint
                offsets[name] = f.tell()
