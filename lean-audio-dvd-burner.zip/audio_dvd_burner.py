#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lean Audio DVD Burner - Phase 1 core pipeline
================================================

Standalone executable Python script implementing the full audio-DVD
pipeline business logic described in the project spec:

    probe_audio()        - ffprobe-based audio compliance check
    prepare_audio()      - pass-through for compliant audio, FFmpeg
                            transcode to 24-bit/48kHz/2ch PCM WAV
                            for non-compliant input
    mux_album_with_lplex()- Wine-wrapped Lplex.exe invocation producing
                            a DVD-Video .iso with correct 18-byte LPCM
                            headers (avoiding the native Linux 12-byte
                            mplex/ffmpeg header bug)
    detect_optical_drives()- lsblk-based CD/DVD drive enumeration
    eject_tray() / close_tray() / poll_drive_ready() / burn_iso()
                          - remote-garage workflow helpers; fully
                            drive-agnostic (script runs to ISO completion
                            even with no optical drive present)
    process_album()       - end-to-end orchestrator (probe -> prepare ->
                            mux -> optional burn)
    batch_process()       - sequential multi-album orchestrator

CLI sub-commands:

    process    Process a single album folder -> ISO (+ optional burn)
    batch      Process multiple album folders sequentially
    probe      Probe one or more audio files (no mutation)
    drive-status   Print optical drive detection result
    burn       Burn an existing .iso to /dev/sr0 (or override)

Environment overrides (all have sensible defaults for Docker layout):

    WINE_CMD     default: wine
    LPLEX_PATH   default: /app/work/lplex/lplex.exe
    DATA_ROOT    default: /app/data
    DVD_DEVICE   default: /dev/sr0

Exit codes:
    0  success
    1  generic pipeline error
    2  probe error (ffprobe missing / unreadable file / unexpected stream)
    3  prepare error (ffmpeg transcode failed)
    4  mux error (lplex non-zero exit / no ISO produced)
    5  burn error (xorriso non-zero / drive not ready)
    6  no optical drive detected when burn requested
   64  CLI usage error

Author: Lean Audio DVD Burner project, Phase 1
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import shlex
import shutil
import subprocess
import sys
import time
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, List, Optional, Sequence

# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------

# Allow environment overrides so the same script can run in Docker, on a
# dev laptop, or in tests without code changes.
WINE_CMD: str = os.environ.get("WINE_CMD", "wine")
LPLEX_PATH: Path = Path(os.environ.get("LPLEX_PATH", "/app/work/lplex/lplex.exe"))
DATA_ROOT: Path = Path(os.environ.get("DATA_ROOT", "/app/data"))
DVD_DEVICE: str = os.environ.get("DVD_DEVICE", "/dev/sr0")

# Audio compliance windows (per DVD-Video LPCM spec, also enforced by lplex).
SUPPORTED_AUDIO_EXT = {".wav", ".flac"}
COMPLIANT_BIT_DEPTHS = {16, 24}
COMPLIANT_SAMPLE_RATES = {48_000, 96_000}
# Spec says "stereo"; lplex actually allows 1-8 channels. We treat the
# "stereo" requirement as soft (warning, not failure) - 1ch / mono also
# passes through. Anything > 2 will be downmixed to stereo in prepare_audio().
STEREO_CHANNEL_COUNT = 2

# Wine produces a LOT of noise on stderr (missing wine32 warnings, XDG_RUNTIME_DIR
# errors, no-display-driver errors, OLE/COM init failures, setupapi errors, etc.)
# lplex is a console app and doesn't need a display, but Wine's startup sequence
# tries to create windows/services anyway. We suppress this noise in two layers:
#   1. Environment variables (WINEDEBUG=-all, DISPLAY=, XDG_RUNTIME_DIR=, etc.)
#   2. A stderr line filter that drops the remaining wine-launcher-script messages
#      that the env vars can't suppress (those are printed by the /usr/bin/wine
#      shell wrapper, not by the Wine debug system).
#
# The env vars below are merged with the existing os.environ when invoking Wine.
_WINE_NOISE_ENV = {
    # Suppress ALL Wine debug channel output (err:, fixme:, warn:, trace:).
    # This is the nuclear option — it silences hundreds of harmless lines about
    # missing display drivers, OLE init failures, setupapi quirks, etc.
    "WINEDEBUG": "-all",
    # Wine needs XDG_RUNTIME_DIR to be set and valid, else it prints an error.
    # In a headless container this var is typically unset.
    "XDG_RUNTIME_DIR": "/tmp",
    # No display server — tells Wine not to try creating windows/systray.
    "DISPLAY": "",
}

# Lines from Wine's stderr that the env vars above can't suppress. These come
# from the /usr/bin/wine shell wrapper script and Wine's initial bootstrap (not
# from the WINEDEBUG debug channel system). We filter them by substring match.
# Any line containing one of these substrings is dropped from the log.
_WINE_NOISE_PATTERNS = [
    # wine launcher script: complains about missing 32-bit support
    "it looks like wine32 is missing",
    "multiarch needs to be enabled first",
    'execute "dpkg --add-architecture',
    "apt-get install wine32",
    # wine first-run: creates the .wine config dir
    "wine: created the configuration directory",
    # wine: XDG_RUNTIME_DIR complaint (redundant since we set it, but just in case)
    "XDG_RUNTIME_DIR is invalid or not set",
    # wine: no display driver
    "nodrv_CreateWindow",
    "The explorer process failed to start",
    "Could not create tray window",
    "Make sure that your display server is running",
    # wine: OLE/COM init failures (caused by no display)
    "err:ole:",
    "Failed to create ifstub",
    "Failed to marshal the interface",
    "apartment_get_local_server_stream",
    "apartment_createwindowifneeded",
    "start_rpcss",
    # wine: setupapi / driver install noise
    "err:setupapi:",
    "err:ntoskrnl:",
    "err:systray:",
    "err:winediag:",
    # wine: rundll32 failure (caused by missing wine32, harmless for lplex)
    "wine: failed to open",
    # wine: generic wine: prefix messages
    "wine: using",
]


def _is_wine_noise_line(line: str) -> bool:
    """Return True if a stderr line from Wine is noise that should be filtered
    out of the log. Uses _WINE_NOISE_PATTERNS for substring matching.

    With WINEDEBUG=-all set, most of these won't appear, but the wine launcher
    script (which wraps the actual wine binary) prints a few messages that
    bypass the debug channel system. This filter catches those.
    """
    lower = line.lower()
    return any(pat.lower() in lower for pat in _WINE_NOISE_PATTERNS)


def _get_wine_env() -> dict:
    """Return a copy of os.environ with Wine noise-suppression vars merged in.

    Used when invoking Wine via subprocess to keep stderr clean.
    """
    env = dict(os.environ)
    env.update(_WINE_NOISE_ENV)
    return env

# Drive status poll cadence (seconds).
DEFAULT_POLL_INTERVAL_SEC = 5
# How long to wait for a disc to be inserted before giving up on the
# optional burn step (seconds). Default 30 minutes - enough time for the
# "remote garage" user to walk over after ISO generation starts.
DEFAULT_BURN_WAIT_SEC = 30 * 60

# DVD-Video compliant background jpeg dimensions (used only for sanity
# checking a user-supplied --bg-image, not strictly enforced).
NTSC_BG_SIZES = {(720, 480), (704, 480), (352, 480), (352, 240)}
PAL_BG_SIZES = {(720, 576), (704, 576), (352, 576), (352, 288)}
ALL_BG_SIZES = NTSC_BG_SIZES | PAL_BG_SIZES

# Module-level logger; configured in main().
log = logging.getLogger("audio_dvd_burner")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------


class PipelineError(Exception):
    """Base class for all pipeline errors. Carries an optional exit code."""

    exit_code: int = 1

    def __init__(self, message: str, exit_code: Optional[int] = None) -> None:
        super().__init__(message)
        if exit_code is not None:
            self.exit_code = exit_code


class ProbeError(PipelineError):
    exit_code = 2


class PrepareError(PipelineError):
    exit_code = 3


class MuxError(PipelineError):
    exit_code = 4


class BurnError(PipelineError):
    exit_code = 5


class NoDriveError(PipelineError):
    exit_code = 6


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AudioProbe:
    """Parsed ffprobe result for a single audio file."""

    path: Path
    bit_depth: Optional[int]      # bits_per_sample (raw)
    sample_rate: Optional[int]     # Hz
    channels: Optional[int]
    codec: Optional[str]           # e.g. "pcm_s24le", "flac"
    duration_sec: float
    compliant: bool
    reason: str = ""               # human-readable compliance verdict

    def as_dict(self) -> dict:
        d = asdict(self)
        d["path"] = str(self.path)
        return d

    def __str__(self) -> str:
        flag = "OK" if self.compliant else "CONVERT"
        return (
            f"{self.path.name}: {self.codec} "
            f"{self.bit_depth or '?'}bit/{self.sample_rate or '?'}Hz "
            f"ch{self.channels or '?'} ({self.duration_sec:.1f}s) [{flag}]"
            + (f" - {self.reason}" if self.reason else "")
        )


@dataclass
class DriveInfo:
    """One optical drive as reported by lsblk."""

    name: str          # e.g. "sr0"
    type: str          # "rom" for optical
    size_bytes: int
    vendor: str = ""
    model: str = ""
    mountpoint: Optional[str] = None
    device: str = ""  # e.g. "/dev/sr0"

    def as_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# probe_audio
# ---------------------------------------------------------------------------


def _require_tool(name: str) -> str:
    """Return absolute path to a required CLI tool, or raise ProbeError."""
    p = shutil.which(name)
    if not p:
        raise ProbeError(
            f"Required external tool '{name}' not found in PATH. "
            f"Install it or ensure it is on PATH inside the container.",
        )
    return p


def probe_audio(path: Path) -> AudioProbe:
    """
    Probe a single audio file with ffprobe and return a parsed AudioProbe.

    Compliance verdict follows the spec:
      * bit depth in {16, 24}
      * sample rate in {48000, 96000}
      * channels == 2 (treated as soft requirement; 1ch passes through)

    Raises ProbeError if ffprobe fails, the file is unreadable, or no
    audio stream is found.
    """
    path = Path(path)
    if not path.is_file():
        raise ProbeError(f"Audio file not found: {path}")

    ffprobe = _require_tool("ffprobe")
    cmd = [
        ffprobe,
        "-v", "error",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        str(path),
    ]
    log.debug("ffprobe cmd: %s", " ".join(shlex.quote(c) for c in cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        raise ProbeError(f"Failed to launch ffprobe on {path}: {exc}") from exc

    if proc.returncode != 0:
        raise ProbeError(
            f"ffprobe exited {proc.returncode} for {path}: "
            f"{proc.stderr.strip() or 'no stderr'}"
        )

    try:
        info = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise ProbeError(f"ffprobe returned non-JSON for {path}: {exc}") from exc

    streams = info.get("streams", []) or []
    audio_streams = [s for s in streams if s.get("codec_type") == "audio"]
    if not audio_streams:
        raise ProbeError(f"No audio stream found in {path}")

    s = audio_streams[0]
    fmt = info.get("format", {}) or {}

    def _to_int(v: Any) -> Optional[int]:
        if v is None:
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    bit_depth = _to_int(s.get("bits_per_sample") or s.get("bits_per_raw_sample"))
    sample_rate = _to_int(s.get("sample_rate"))
    channels = _to_int(s.get("channels"))
    codec = s.get("codec_name")
    duration_sec = float(_to_int(fmt.get("duration")) or 0.0) if fmt.get("duration") else 0.0
    # duration may be float string
    try:
        duration_sec = float(fmt.get("duration") or 0.0)
    except (TypeError, ValueError):
        duration_sec = 0.0

    # Compliance check
    reasons: List[str] = []
    if bit_depth is None or bit_depth not in COMPLIANT_BIT_DEPTHS:
        reasons.append(
            f"bit_depth {bit_depth} not in {sorted(COMPLIANT_BIT_DEPTHS)}"
        )
    if sample_rate is None or sample_rate not in COMPLIANT_SAMPLE_RATES:
        reasons.append(
            f"sample_rate {sample_rate} not in {sorted(COMPLIANT_SAMPLE_RATES)}"
        )
    if channels is None or channels < 1:
        reasons.append(f"channels {channels} invalid")
    elif channels != STEREO_CHANNEL_COUNT:
        # soft requirement - flag in reason but still mark compliant if other
        # fields pass, so that mono passes through untouched. We only mark
        # non-compliant if channels > 2 (needs downmix).
        if channels > STEREO_CHANNEL_COUNT:
            reasons.append(
                f"channels {channels} > {STEREO_CHANNEL_COUNT} (will downmix)"
            )

    compliant = not reasons
    return AudioProbe(
        path=path,
        bit_depth=bit_depth,
        sample_rate=sample_rate,
        channels=channels,
        codec=codec,
        duration_sec=duration_sec,
        compliant=compliant,
        reason="; ".join(reasons),
    )


# ---------------------------------------------------------------------------
# prepare_audio
# ---------------------------------------------------------------------------

# Conversion table (user-specified) for non-compliant audio.
# When the input is compliant (16/24-bit @ 48/96kHz, channels <= 2, .wav/.flac),
# the file is passed through to lplex unchanged. Otherwise:
#
#   | Input             | Output              |
#   | ----------------- | ------------------- |
#   | 16-bit / 44.1 kHz | 16-bit / 48 kHz     |
#   | 16-bit / 48 kHz   | 16-bit / 48 kHz (pass-through) |
#   | 16-bit / 88.2 kHz | 16-bit / 96 kHz     |
#   | 16-bit / 96 kHz   | 16-bit / 96 kHz (pass-through)  |
#   | 24-bit / 44.1 kHz | 24-bit / 48 kHz     |
#   | 24-bit / 48 kHz   | 24-bit / 48 kHz (pass-through)  |
#   | 24-bit / 88.2 kHz | 24-bit / 96 kHz     |
#   | 24-bit / 96 kHz   | 24-bit / 96 kHz (pass-through)  |
#
# Generalised rules (covers rates the table doesn't enumerate, e.g. 22.05k,
# 176.4k, 192k, 32-bit float, 20-bit, etc.):
#   * Bit depth: 16 → 16, 24 → 24, anything else (32-bit float, 20-bit, etc.)
#     → 24 (the nearest lplex-legal depth; 20-bit is explicitly unsupported
#     by lplex per its readme).
#   * Sample rate:
#       - input <= 48000 Hz           → 48000 Hz
#       - input  > 48000 and != 96000  → 96000 Hz  (covers 88.2k, 176.4k, 192k)
#       - input == 96000               → 96000 Hz  (pass-through; unreachable here)
#   * Channels: 1 → 1 (preserve mono), 2 → 2 (preserve stereo), >2 → 2 (downmix).
#
# Upsampling uses the soxr resampler (libsoxr) at precision=28 bits, which
# libsoxr recommends for 24-bit audio (default is 20 bits).
SOXR_PRECISION = 28


def _target_format(probe: AudioProbe) -> tuple[int, int, int]:
    """
    Pick the (bit_depth, sample_rate, channels) to transcode to, based on the
    user-specified conversion table.

    See the module-level table comment just above this function for the rules.
    """
    # Bit depth: preserve 16 or 24, otherwise default to 24
    if probe.bit_depth in (16, 24):
        target_bit_depth = probe.bit_depth
    else:
        # 32-bit float, 20-bit, 8-bit, unknown, etc. → 24-bit (lplex-legal max)
        target_bit_depth = 24

    # Sample rate: anything ≤ 48k maps to 48k; anything > 48k that isn't 96k
    # maps to 96k. (96k itself is unreachable here — it's a pass-through case.)
    if probe.sample_rate is None or probe.sample_rate <= 48_000:
        target_sample_rate = 48_000
    else:
        target_sample_rate = 96_000

    # Channels: downmix to stereo only when > 2; preserve mono (1) and stereo (2)
    if probe.channels is None or probe.channels > 2:
        target_channels = 2
    else:
        target_channels = probe.channels

    return target_bit_depth, target_sample_rate, target_channels


def _pcm_codec_for_bit_depth(bit_depth: int) -> str:
    """Return the FFmpeg PCM codec name for the given bit depth (WAV output)."""
    if bit_depth == 16:
        return "pcm_s16le"
    if bit_depth == 24:
        return "pcm_s24le"
    # Shouldn't happen since _target_format() always returns 16 or 24, but
    # fall back to 24-bit if it ever does.
    return "pcm_s24le"


def _output_extension(src: Path) -> str:
    """Decide the output file extension for a transcode based on the input
    container. We preserve the input container format: .wav in -> .wav out,
    .flac in -> .flac out. This means a non-compliant FLAC stays FLAC after
    resampling (the user's explicit requirement).
    """
    ext = src.suffix.lower()
    if ext == ".flac":
        return ".flac"
    # Default to WAV for everything else (including .wav and unknown formats).
    # lplex accepts both .wav and .flac natively.
    return ".wav"


def _ffmpeg_encoder_for(extension: str, bit_depth: int) -> tuple[str, list[str]]:
    """Return the (encoder_name, extra_args) tuple for ffmpeg to write the
    given bit depth in the given container.

    For .wav: pcm_s16le / pcm_s24le (no extra args needed)
    For .flac: flac encoder with -sample_fmt s16 (16-bit) or
        -sample_fmt s32 -bits_per_raw_sample 24 (24-bit). FLAC stores
        24-bit audio inside a 32-bit container; -bits_per_raw_sample=24
        tells libFLAC to actually use 24 bits of precision.
    """
    if extension == ".flac":
        if bit_depth == 16:
            return "flac", ["-sample_fmt", "s16"]
        if bit_depth == 24:
            return "flac", ["-sample_fmt", "s32", "-bits_per_raw_sample", "24"]
        # _target_format() guarantees 16 or 24, but fall back to 24.
        return "flac", ["-sample_fmt", "s32", "-bits_per_raw_sample", "24"]
    # WAV
    return _pcm_codec_for_bit_depth(bit_depth), []


def prepare_audio(src: Path, dst_dir: Path) -> Path:
    """
    Prepare an audio file for lplex muxing.

    Pass-through (ORIGINAL file returned, ZERO modifications) if:
      * extension is .wav OR .flac AND
      * ffprobe reports 16 or 24-bit AND
      * sample rate is 48000 or 96000 Hz AND
      * channels <= 2 (mono and stereo both pass through untouched)

    Lplex natively accepts both .wav and .flac at 16/24-bit / 48/96kHz, so
    compliant files are passed directly to lplex without any copy or
    transcode — neither their bytes nor their path are touched. This is
    the user's explicit requirement: "If they are in 96khz 24 bit they
    should be directly passed through to lplex, nothing should be done
    with them".

    Otherwise, transcode with FFmpeg following the user-specified
    conversion table (see the module-level comment above _target_format()):

        | Input             | Output              |
        | ----------------- | ------------------- |
        | 16-bit / 44.1 kHz | 16-bit / 48 kHz     |
        | 16-bit / 88.2 kHz | 16-bit / 96 kHz     |
        | 24-bit / 44.1 kHz | 24-bit / 48 kHz     |
        | 24-bit / 88.2 kHz | 24-bit / 96 kHz     |
        | 16/24-bit / 48 kHz   | pass-through         |
        | 16/24-bit / 96 kHz   | pass-through         |

    Bit depth is PRESERVED (16-bit input → 16-bit output; we do not pad to
    24-bit, which would waste space without adding quality). Sample rate is
    mapped to the nearest lplex-legal rate (48k for anything ≤ 48k, 96k for
    anything > 48k). Channels > 2 are downmixed to stereo; mono is preserved.

    The input CONTAINER format is also preserved: a non-compliant .flac is
    resampled and re-encoded as .flac (NOT .wav), per the user's request:
    "I see that when you have to resample you convert into .wav. Can you
    keep it in flac?". A non-compliant .wav stays .wav.

    The soxr resampler (libsoxr) is used at precision=28 bits, the libsoxr
    recommendation for 24-bit audio (default is 20 bits).

    Returns:
      * For pass-through: the ORIGINAL source Path (no file is copied,
        no bytes are read or written; the staging dir is left untouched).
      * For transcode: the Path of the new file inside dst_dir, with the
        same extension as the source (.wav or .flac).

    Raises PrepareError on any failure.
    """
    src = Path(src)
    if not src.is_file():
        raise PrepareError(f"Source audio not found: {src}")

    probe = probe_audio(src)

    # Pass-through: compliant wav/flac → return the ORIGINAL path, no copy
    if src.suffix.lower() in SUPPORTED_AUDIO_EXT and probe.compliant:
        log.info("prepare pass-through (original, untouched): %s", src)
        return src

    # Transcode path: only reached for non-compliant audio
    dst_dir = Path(dst_dir)
    dst_dir.mkdir(parents=True, exist_ok=True)
    base = src.stem
    safe_stem = "".join(c if c.isalnum() or c in "._-" else "_" for c in base)

    # Preserve the input container (FLAC in -> FLAC out, WAV in -> WAV out)
    out_ext = _output_extension(src)
    dst = dst_dir / f"{safe_stem}{out_ext}"

    target_bit_depth, target_sample_rate, target_channels = _target_format(probe)
    encoder, encoder_extra_args = _ffmpeg_encoder_for(out_ext, target_bit_depth)

    ffmpeg = _require_tool("ffmpeg")
    # aresample filter per spec; explicit flags avoid auto-channel/layout issues.
    # soxr precision=28 is libsoxr's recommendation for 24-bit audio.
    cmd = [
        ffmpeg,
        "-y",                              # overwrite
        "-hide_banner",
        "-loglevel", "error",
        "-i", str(src),
        "-vn",                             # no video
        "-c:a", encoder,                   # pcm_s16le / pcm_s24le / flac
        *encoder_extra_args,               # FLAC: -sample_fmt, -bits_per_raw_sample
        "-ar", str(target_sample_rate),    # 48000 or 96000
        "-ac", str(target_channels),       # 1 (mono), 2 (stereo), or 2 (downmix)
        "-af", f"aresample={target_sample_rate}:resampler=soxr:precision={SOXR_PRECISION}",
        str(dst),
    ]
    log.info(
        "prepare transcode: %s -> %s (target: %dbit/%dkHz/ch%d, %s, soxr precision=%d)",
        src, dst, target_bit_depth, target_sample_rate // 1000, target_channels,
        out_ext.lstrip("."), SOXR_PRECISION,
    )
    log.debug("ffmpeg cmd: %s", " ".join(shlex.quote(c) for c in cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        raise PrepareError(f"Failed to launch ffmpeg on {src}: {exc}") from exc
    if proc.returncode != 0:
        # Clean up partial output if any
        if dst.exists():
            try:
                dst.unlink()
            except OSError:
                pass
        raise PrepareError(
            f"ffmpeg transcode failed (exit {proc.returncode}) for {src}: "
            f"{proc.stderr.strip() or 'no stderr'}"
        )
    return dst


# ---------------------------------------------------------------------------
# Optical drive helpers
# ---------------------------------------------------------------------------


def detect_optical_drives() -> List[DriveInfo]:
    """
    Enumerate optical disc drives via lsblk.

    Returns a (possibly empty) list of DriveInfo objects. Never raises
    on missing tools - returns [] instead, so callers can branch cleanly.
    """
    lsblk = shutil.which("lsblk")
    if not lsblk:
        log.warning("lsblk not available - cannot enumerate optical drives")
        return []
    cmd = [
        lsblk,
        "-J",                 # JSON output
        "-b",                 # bytes
        "-o", "NAME,TYPE,SIZE,MOUNTPOINT,MODEL,VENDOR",
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        log.warning("Failed to run lsblk: %s", exc)
        return []
    if proc.returncode != 0:
        log.warning("lsblk exited %d: %s", proc.returncode, proc.stderr.strip())
        return []
    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        log.warning("lsblk returned non-JSON: %s", exc)
        return []

    drives: List[DriveInfo] = []
    for blk in data.get("blockdevices", []) or []:
        # Optical drives show up as TYPE=rom (sometimes TYPE=disk for some
        # sd-card-style readers, but we only treat rom as optical).
        if blk.get("type") != "rom":
            continue
        name = blk.get("name", "")
        drives.append(
            DriveInfo(
                name=name,
                type="rom",
                size_bytes=int(blk.get("size", 0) or 0),
                vendor=blk.get("vendor", "") or "",
                model=blk.get("model", "") or "",
                mountpoint=blk.get("mountpoint"),
                device=f"/dev/{name}",
            )
        )
    return drives


def drive_status(device: str = DVD_DEVICE) -> dict:
    """
    Inspect optical drive readiness.

    Returns a dict:
        {"device": "/dev/sr0", "exists": bool, "has_disc": bool,
         "tray_state": "unknown"|"closed-no-media"|"ready"}

    "has_disc" is True iff a disc is inserted and ready for I/O.
    We use `blkid <device>` as the probe: it returns 0 if media is
    present, non-zero (typically 2) if no medium or tray open.
    """
    device_path = Path(device)
    exists = device_path.exists()
    if not exists:
        return {"device": device, "exists": False, "has_disc": False,
                "tray_state": "no-such-device"}

    blkid = shutil.which("blkid")
    if not blkid:
        # Fallback: try to read 1 byte from the device
        try:
            with open(device, "rb", buffering=0) as f:
                f.read(1)
            return {"device": device, "exists": True, "has_disc": True,
                    "tray_state": "ready"}
        except OSError:
            return {"device": device, "exists": True, "has_disc": False,
                    "tray_state": "closed-no-media"}

    proc = subprocess.run(
        [blkid, device], capture_output=True, text=True, check=False
    )
    has_disc = proc.returncode == 0
    return {
        "device": device,
        "exists": True,
        "has_disc": has_disc,
        "tray_state": "ready" if has_disc else "closed-no-media",
    }


def eject_tray(device: str = DVD_DEVICE) -> None:
    """Eject the optical drive tray. No-op (with warning) if no drive."""
    eject = shutil.which("eject")
    if not eject:
        log.warning("eject not available - cannot eject %s", device)
        return
    proc = subprocess.run(
        [eject, device], capture_output=True, text=True, check=False
    )
    if proc.returncode != 0:
        log.warning(
            "eject %s returned %d: %s",
            device, proc.returncode, proc.stderr.strip() or "(no stderr)",
        )
    else:
        log.info("Tray ejected on %s", device)


def close_tray(device: str = DVD_DEVICE) -> None:
    """Close the optical drive tray (eject -t). No-op (with warning) if no drive."""
    eject = shutil.which("eject")
    if not eject:
        log.warning("eject not available - cannot close tray %s", device)
        return
    proc = subprocess.run(
        [eject, "-t", device], capture_output=True, text=True, check=False
    )
    if proc.returncode != 0:
        log.warning(
            "eject -t %s returned %d: %s",
            device, proc.returncode, proc.stderr.strip() or "(no stderr)",
        )
    else:
        log.info("Tray closed on %s", device)


def poll_drive_ready(
    device: str = DVD_DEVICE,
    timeout_sec: int = DEFAULT_BURN_WAIT_SEC,
    poll_interval_sec: int = DEFAULT_POLL_INTERVAL_SEC,
) -> bool:
    """
    Poll the optical drive until a disc is inserted and ready, or timeout.

    Returns True when media is ready for burning, False on timeout.
    Uses `blkid <device>` (returncode 0 = media present) as the probe.
    """
    deadline = time.monotonic() + max(0, timeout_sec)
    while True:
        status = drive_status(device)
        if status["has_disc"]:
            log.info("Drive %s ready (disc detected)", device)
            return True
        if time.monotonic() >= deadline:
            log.warning(
                "Drive %s not ready after %ds - skipping burn",
                device, timeout_sec,
            )
            return False
        time.sleep(poll_interval_sec)


def burn_iso(
    iso_path: Path,
    device: str = DVD_DEVICE,
    speed: int = 4,
) -> None:
    """
    Burn an .iso to the optical drive using xorriso.

    Uses xorriso's `cdrecord` emulation mode (`xorriso -as cdrecord`),
    which is the standard, well-tested way to write a pre-authored ISO
    image to DVD media. We pass `-dao` (Disk-At-Once) so the disc is
    closed after the burn — this is the correct mode for single-session
    DVD-R media. `-eject` pops the tray once the burn completes so the
    user can retrieve the disc without an extra step.

    Raises BurnError on any failure. Does NOT poll the drive beforehand -
    callers should ensure the drive is ready (e.g. via poll_drive_ready).
    """
    iso_path = Path(iso_path)
    if not iso_path.is_file():
        raise BurnError(f"ISO file not found: {iso_path}")
    if iso_path.stat().st_size == 0:
        raise BurnError(f"ISO file is empty: {iso_path}")

    xorriso = shutil.which("xorriso")
    if not xorriso:
        raise BurnError(
            "xorriso not found in PATH. Install xorriso "
            "(e.g. `apt-get install xorriso`) in the container image."
        )

    # xorriso -as cdrecord: emulate cdrecord for writing a pre-authored ISO.
    # -v               : verbose progress to stderr
    # dev=<device>     : target optical device
    # speed=<n>        : burn speed multiplier
    # -dao             : Disk-At-Once (single-session, closes disc)
    # -eject           : eject tray after burn completes
    # <iso>            : the pre-authored ISO image to write (positional)
    cmd = [
        xorriso,
        "-as", "cdrecord",
        "-v",
        f"dev={device}",
        f"speed={int(speed)}",
        "-dao",
        "-eject",
        str(iso_path),
    ]
    log.info("Burning %s to %s (speed=%dx, dao)", iso_path, device, speed)
    log.debug("xorriso cmd: %s", " ".join(shlex.quote(c) for c in cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        raise BurnError(f"Failed to launch xorriso: {exc}") from exc
    if proc.returncode != 0:
        raise BurnError(
            f"xorriso exited {proc.returncode}: "
            f"{proc.stderr.strip() or proc.stdout.strip() or 'no output'}"
        )
    log.info("Burn completed: %s on %s", iso_path, device)


# ---------------------------------------------------------------------------
# Lplex muxing
# ---------------------------------------------------------------------------

# Characters we keep in pass-through file names passed to lplex via Wine.
# Anything outside this set is replaced with an underscore and a symlink
# is created so the original file is never modified.
#
# Reason: lplex.exe runs under Wine, which maps Linux paths into the Windows
# Z: drive. Non-ASCII filenames (e.g., the Unicode HYPHEN U+2010 — bytes
# \342\200\220 — that some macOS tools auto-substitute for ASCII hyphen)
# cause lplex to refuse to open the file. Rather than touching the user's
# audio, we create a symlink in the staging dir with a sanitized ASCII
# name pointing back at the original, and pass the symlink path to lplex.
#
# This set is intentionally narrow: ASCII letters, digits, and a small list
# of common safe punctuation. Slashes and other path separators are not in
# this set (the filename stem is checked, not the directory part).
_SAFE_FILENAME_CHARS = set(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "._-()[]{} "
)


def _has_unsafe_chars(name: str) -> bool:
    """Return True if `name` (a file stem or basename) contains any character
    outside the safe ASCII set.
    """
    return any(c not in _SAFE_FILENAME_CHARS for c in name)


def _sanitize_filename(name: str) -> str:
    """Replace any character outside _SAFE_FILENAME_CHARS with an underscore.

    If the sanitized name is empty or all-underscores (e.g., the input was
    all unsafe chars), returns 'audio' as a fallback so we don't end up with
    an empty filename or a name like '___'.
    """
    sanitized = "".join(c if c in _SAFE_FILENAME_CHARS else "_" for c in name)
    # Strip leading/trailing underscores and whitespace
    sanitized = sanitized.strip("_ ").strip() or "audio"
    return sanitized


def _safe_pass_through_path(src: Path, staging_dir: Path) -> Path:
    """Return a path that lplex (via Wine) can safely open for `src`.

    If `src`'s name contains only safe ASCII characters, returns `src` itself
    — no symlink, no copy, no modification of any kind.

    If `src`'s name contains non-ASCII or otherwise unsafe characters (e.g.,
    the U+2010 Unicode HYPHEN that macOS apps auto-substitute for the ASCII
    hyphen, bytes \\342\\200\\220 in UTF-8), creates a symlink in
    `staging_dir` with a sanitized ASCII name pointing at the absolute path
    of `src`, and returns the symlink path.

    The original file is NEVER modified — only a symlink is added to the
    staging dir. If a symlink with the sanitized name already exists and
    points to the same target, the existing symlink is reused.

    Raises PrepareError if the symlink cannot be created.
    """
    src = Path(src).resolve()
    name = src.name
    if not _has_unsafe_chars(name):
        return src

    # Need a sanitized name. Disambiguate by appending a short hash of the
    # original name so two distinct Unicode names that sanitize to the same
    # ASCII don't collide.
    import hashlib
    safe_stem = _sanitize_filename(src.stem)
    digest = hashlib.md5(name.encode("utf-8")).hexdigest()[:8]
    symlink_name = f"{safe_stem}_{digest}{src.suffix}"
    staging_dir.mkdir(parents=True, exist_ok=True)
    symlink_path = staging_dir / symlink_name

    if symlink_path.is_symlink():
        # Existing symlink — verify it points at our target
        try:
            existing_target = symlink_path.resolve()
            if existing_target == src:
                log.info(
                    "prepare pass-through symlink (reused): %s -> %s",
                    symlink_path, src,
                )
                return symlink_path
        except OSError:
            pass
        # Otherwise overwrite below
        try:
            symlink_path.unlink()
        except OSError as exc:
            raise PrepareError(
                f"Could not remove stale symlink {symlink_path}: {exc}"
            ) from exc

    log.info(
        "prepare pass-through symlink: %s -> %s (non-ASCII filename sanitized)",
        symlink_path, src,
    )
    try:
        symlink_path.symlink_to(src)
    except OSError as exc:
        raise PrepareError(
            f"Could not create symlink {symlink_path} -> {src}: {exc}"
        ) from exc
    return symlink_path


def _find_video_ts_folder(output_dir: Path) -> Optional[Path]:
    """Search for a VIDEO_TS folder created by lplex under output_dir.

    lplex with -c dvd typically writes:
        <output_dir>/<project_name>/VIDEO_TS/...
    or, in some configurations:
        <output_dir>/VIDEO_TS/...

    Searches recursively up to 3 levels deep. Returns the parent folder that
    CONTAINS VIDEO_TS (so the path can be passed to mkisofs as the source
    directory), or None if no VIDEO_TS folder is found.
    """
    # First check the common case: VIDEO_TS directly under output_dir
    direct = output_dir / "VIDEO_TS"
    if direct.is_dir():
        return output_dir

    # Then search one level deep (the <project_name>/VIDEO_TS case)
    for child in output_dir.iterdir():
        if child.is_dir():
            vt = child / "VIDEO_TS"
            if vt.is_dir():
                return child

    # Finally, two levels deep (paranoid case)
    for child in output_dir.iterdir():
        if not child.is_dir():
            continue
        for grandchild in child.iterdir():
            if grandchild.is_dir():
                vt = grandchild / "VIDEO_TS"
                if vt.is_dir():
                    return grandchild

    return None


def _sanitize_volume_label(name: str) -> str:
    """Sanitize a project name into a DVD volume label.

    mkisofs/xorriso require the volume label to be < 32 bytes and contain
    only ASCII uppercase characters (digits and a few punctuation chars
    are also allowed). We uppercase, replace unsafe chars with underscore,
    and truncate to 31 chars.
    """
    # Allow A-Z, 0-9, _, -, space — but mkisofs uppercases anyway
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_ -")
    sanitized = "".join(c if c.upper() in allowed else "_" for c in name)
    # Collapse multiple underscores/spaces
    import re
    sanitized = re.sub(r"[_ ]+", "_", sanitized).strip("_")
    sanitized = sanitized.upper() or "AUDIO_DVD"
    return sanitized[:31]


def _sanitize_iso_filename(name: str) -> str:
    """Sanitize an album name into a safe .iso filename.

    Replaces spaces and non-ASCII chars with underscores so the resulting
    ISO file path is easy to type at the CLI (no shell quoting needed) and
    portable across filesystems. The original album name is preserved as
    the DVD volume label inside the ISO (via _sanitize_volume_label), so
    DVD players still show the readable name.

    Rules:
      * ASCII letters, digits, and `._-` are preserved.
      * Spaces and any other char (including non-ASCII) become `_`.
      * Collapsed consecutive underscores.
      * Strips leading/trailing underscores.
      * Empty result falls back to "audio_dvd".

    Examples:
      "An Awesome Wave"        → "An_Awesome_Wave"
      "Café del Mar"           → "Caf_del_Mar"
      "track\u2010unicode"     → "track_unicode"
    """
    allowed = set("abcdefghijklmnopqrstuvwxyz"
                  "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  "0123456789"
                  "._-")
    sanitized = "".join(c if c in allowed else "_" for c in name)
    # Collapse multiple underscores
    import re
    sanitized = re.sub(r"_+", "_", sanitized).strip("_")
    return sanitized or "audio_dvd"


def create_iso_from_video_ts(
    dvd_folder: Path,
    iso_path: Path,
    volume_label: str,
) -> Path:
    """Create a DVD-Video ISO image from a folder containing a VIDEO_TS
    subdirectory.

    Tool priority (for DVD-Video compliance):
      1. `mkisofs` — supports -dvd-video (sector alignment) and -udf natively.
         On Debian/Ubuntu, install `genisoimage` (which provides `mkisofs`).
      2. `genisoimage` — same as mkisofs on Debian/Ubuntu (genisoimage IS the
         mkisofs implementation in the cdrkit package).
      3. `xorriso -as mkisofs` — does NOT support -dvd-video or -udf (per the
         official xorriso man page at https://man.archlinux.org/man/xorriso.1.en,
         the supported option list is: -R, -r, -J, -o, -M, -C, -dir-mode,
         -file-mode, -path-list, -m, -exclude-list, -f, -print-size, -pad,
         -no-pad, -V, -v, -version, -graft-points, -z, -no-emul-boot, -b,
         -c, -boot-info-table, -boot-load-size, -input-charset, -G,
         -output-charset, -U, -hide, -hide-joliet, -hide-list,
         -hide-joliet-list, file paths and pathspecs).
         We use it as a last-resort fallback WITHOUT -dvd-video/-udf, with a
         warning that the resulting disc may not be sector-aligned for older
         DVD players (modern players should still work fine).

    The lplex-compatible command shape is:
        mkisofs -dvd-video -V "<volid>" -udf -o "<output.iso>" "<dvd_folder>"

    Args:
        dvd_folder: A folder that contains a VIDEO_TS subdirectory.
        iso_path: Path where the .iso file should be written.
        volume_label: DVD volume label (will be sanitized to ASCII
            uppercase, max 31 chars per mkisofs spec).

    Returns the iso_path on success. Raises MuxError on any failure.
    """
    dvd_folder = Path(dvd_folder)
    iso_path = Path(iso_path)

    if not dvd_folder.is_dir():
        raise MuxError(f"DVD folder not found: {dvd_folder}")
    if not (dvd_folder / "VIDEO_TS").is_dir():
        raise MuxError(
            f"Not a DVD folder (no VIDEO_TS subdirectory): {dvd_folder}"
        )

    iso_path.parent.mkdir(parents=True, exist_ok=True)

    volid = _sanitize_volume_label(volume_label)

    # Pick the ISO creation tool, in priority order.
    mkisofs_bin = shutil.which("mkisofs")
    genisoimage_bin = shutil.which("genisoimage")
    xorriso_bin = shutil.which("xorriso")

    if mkisofs_bin is not None:
        # Real mkisofs (or genisoimage on Debian/Ubuntu, which provides mkisofs
        # as a symlink). Supports -dvd-video and -udf natively — best path.
        cmd = [
            mkisofs_bin,
            "-dvd-video",
            "-V", volid,
            "-udf",
            "-o", str(iso_path),
            str(dvd_folder),
        ]
        tool_name = "mkisofs"
    elif genisoimage_bin is not None:
        # genisoimage directly (cdrkit fork of mkisofs; supports -dvd-video).
        cmd = [
            genisoimage_bin,
            "-dvd-video",
            "-V", volid,
            "-udf",
            "-o", str(iso_path),
            str(dvd_folder),
        ]
        tool_name = "genisoimage"
    elif xorriso_bin is not None:
        # Last-resort fallback: xorriso -as mkisofs. Does NOT support
        # -dvd-video or -udf per the official xorriso man page. The resulting
        # ISO is plain ISO 9660 + Rock Ridge (no UDF, no DVD-Video sector
        # alignment). Modern software players and most modern DVD players
        # will still play it (they don't strictly require the sector
        # alignment), but strict/older players may reject the disc.
        log.warning(
            "Neither mkisofs nor genisoimage is available — falling back "
            "to `xorriso -as mkisofs` WITHOUT -dvd-video/-udf. The resulting "
            "ISO will NOT be sector-aligned per the DVD-Video spec; modern "
            "players should still work, but older/strict players may "
            "reject the disc. Install `genisoimage` "
            "(e.g. `apt-get install genisoimage`) in the container image "
            "for proper DVD-Video compliance."
        )
        cmd = [
            xorriso_bin,
            "-as", "mkisofs",
            "-V", volid,
            "-o", str(iso_path),
            str(dvd_folder),
        ]
        tool_name = "xorriso (no -dvd-video)"
    else:
        raise MuxError(
            "No ISO creation tool found in PATH. Install one of: "
            "mkisofs (cdrtools), genisoimage (cdrkit, recommended on "
            "Debian/Ubuntu — provides the `mkisofs` command), or xorriso "
            "(fallback, less DVD-Video-compliant)."
        )

    log.info(
        "Building ISO: %s from %s (tool: %s, volume label: %s)",
        iso_path, dvd_folder, tool_name, volid,
    )
    log.debug("ISO cmd: %s", " ".join(shlex.quote(c) for c in cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        raise MuxError(f"Failed to launch {tool_name}: {exc}") from exc
    if proc.returncode != 0:
        raise MuxError(
            f"{tool_name} exited {proc.returncode}: "
            f"{proc.stderr.strip() or proc.stdout.strip() or 'no output'}"
        )
    if not iso_path.is_file() or iso_path.stat().st_size == 0:
        raise MuxError(
            f"{tool_name} reported success but no .iso file was produced "
            f"at {iso_path}"
        )
    log.info(
        "ISO built: %s (%d bytes)",
        iso_path, iso_path.stat().st_size,
    )
    return iso_path


def build_lplex_command(
    album_name: str,
    output_dir: Path,
    audio_files: Sequence[Path],
    *,
    titleset_groups: Optional[Sequence[Sequence[Path]]] = None,
    blank_video: Optional[Path] = None,
    bg_preset: str = "black",
    bg_image: Optional[Path] = None,
    media: str = "dvd-r",
    create: str = "dvd",
    title_flag: str = "name",
    lplex_format: Optional[str] = None,
    alignment: str = "seamless",
    shift: str = "backward",
    tv_standard: Optional[str] = None,
    verbose: bool = False,
    extra_args: Sequence[str] = (),
) -> List[str]:
    """
    Build the lplex command line.

    For a SINGLE album (one titleset), pass `audio_files` as a flat list:
        build_lplex_command("MyAlbum", out, [file1, file2])

    For MULTIPLE albums on ONE DVD (multiple titlesets), pass
    `titleset_groups` as a list of lists — each sublist is one album's files.
    The builder inserts the `ts` flag between groups, which tells lplex to
    start a new titleset:
        build_lplex_command("Compilation", out, [],
            titleset_groups=[[album1_files], [album2_files], [album3_files]])
    Produces:
        lplex ... album1_files... ts album2_files... ts album3_files...

    The `ts` flag is lplex's positional flag for "start a new titleset here"
    (see lplex --help, Flags section). Each titleset becomes a separate title
    on the DVD, navigable via the DVD player's "next"/"prev" controls.

    Notes:
      * lplex 0.3's actual flag is `--name` / `-n`, NOT `--title`. We default
        to `--name` to match the bundled lplex.exe. Override via
        title_flag="title" if you ship a different lplex build.
      * lplex 0.3 has NO `-o` flag. The correct flag for "output directory"
        is `-d` / `--dir` ("output everything to this directory"). The spec
        template's `-o` was wrong — it caused the error
        "unknown option -- o" when invoked via Wine. Switched to `-d`.
      * We default to `-c dvd` (create = "dvd"), NOT lplex's own default
        `-c iso`. Reason: lplex's iso stage calls its bundled `mkisofs.exe`,
        which fails under Wine with the error:
            Z:\\app\\work\\lplex\\bin\\mkisofs.exe not supported on this system
        Stopping at `dvd` produces a VIDEO_TS folder via `dvdauthor.exe`
        (which DOES work in Wine), and we then build the ISO ourselves with
        `xorriso -as mkisofs -dvd-video -V <volid> -udf -o <iso> <dvd_dir>`.
        Override via create="iso" / "mpeg" / "lpcm" / "m2v" / "dvdstyler"
        if you need a different stage (mostly for debugging).
      * The "blank video" positional in the spec is unusual - lplex 0.3
        normally takes the background image via `-j <jpg|black|black_L|...>`.
        We support both:
          - blank_video=<path>: prepended as first positional (spec-faithful)
          - bg_image=<path>:   passed via -j =<path>
          - bg_preset:        passed via -j <preset> (default "black")
        If both are given, bg_image takes precedence.
      * Audio files are always passed as positionals (after any blank_video).
      * --verbose is NOT added by default; lplex's own default is "no" per
        its ini file. Pass verbose=True to explicitly enable verbose output.
    """
    output_dir = Path(output_dir)
    cmd: List[str] = [WINE_CMD, str(LPLEX_PATH)]

    # DVD title / name
    if title_flag not in ("name", "title"):
        raise ValueError(f"title_flag must be 'name' or 'title', got {title_flag!r}")
    flag = "--name" if title_flag == "name" else "--title"
    cmd.extend([flag, album_name])

    # Media target
    if media not in ("dvd-r", "dvd+r", "dl", "none"):
        raise ValueError(f"media must be dvd-r/dvd+r/dl/none, got {media!r}")
    cmd.extend(["-z", media])

    # Create stage. lplex's own default is "iso", which calls its bundled
    # mkisofs.exe — that binary fails under Wine with
    # "Z:\\app\\work\\lplex\\bin\\mkisofs.exe not supported on this system".
    # We default to "dvd" so lplex stops at the VIDEO_TS folder (created via
    # dvdauthor.exe, which DOES work in Wine), then we build the ISO ourselves
    # using `xorriso -as mkisofs` (see create_iso_from_video_ts()).
    if create not in ("lpcm", "m2v", "dvdstyler", "mpeg", "dvd", "iso"):
        raise ValueError(
            f"create must be lpcm/m2v/dvdstyler/mpeg/dvd/iso, got {create!r}"
        )
    cmd.extend(["-c", create])

    # Output directory (lplex 0.3's -d / --dir; spec template's -o was wrong)
    cmd.extend(["-d", str(output_dir)])

    # Cleanup: explicitly disable. lplex's default is --cleanup=yes which
    # deletes its intermediate files (.m2v, .lpcm, .mpg) after muxing. That's
    # fine for lplex's own intermediates, BUT it also tries to delete files
    # inside the output_dir that it didn't create (like our _staging_ dir with
    # transcoded audio). This produces "*ERR: Unable to remove" messages in
    # the log. Setting --cleanup=no prevents these errors. We clean up
    # lplex's intermediates ourselves in the orchestrator (cleanup_intermediate
    # flag controls whether the staging dir is removed after mux).
    cmd.extend(["-C", "no"])

    # Format flag (-f) - optional, not in spec template but appears in Phase 0
    # validation task. lplex 0.3 actually uses --formatout for extraction only;
    # we pass it through verbatim in case a different build uses it.
    if lplex_format:
        cmd.extend(["-f", lplex_format])

    # TV standard (pal/ntsc) - optional
    if tv_standard:
        cmd.extend(["-t", tv_standard])

    # Splice (alignment)
    if alignment not in ("seamless", "discrete", "padded", "none"):
        raise ValueError(
            f"alignment must be seamless/discrete/padded/none, got {alignment!r}"
        )
    cmd.extend(["-l", alignment])
    if alignment == "seamless":
        if shift not in ("backward", "forward", "nearest"):
            raise ValueError(
                f"shift must be backward/forward/nearest, got {shift!r}"
            )
        cmd.extend(["-s", shift])

    # Background image: prefer explicit file, else preset, else default black.
    # NOTE: file existence is validated by mux_album_with_lplex; this function
    # is a pure command builder and must not touch the filesystem (so that
    # tests can construct commands with synthetic paths).
    if bg_image is not None:
        bg_image = Path(bg_image)
        cmd.extend(["-j", f"={bg_image}"])
    elif blank_video is not None:
        # Spec-faithful: pass blank video as first positional (will warn)
        log.warning(
            "Passing blank_video as positional (spec template). Note: lplex "
            "0.3 expects audio files/folders as positionals and the background "
            "via -j. If you hit 'unknown file type' errors, use --bg-image "
            "instead."
        )
    else:
        cmd.extend(["-j", bg_preset])

    # Verbose: only emit if user explicitly opted in. lplex's own default
    # (per its ini file) is "no", so omitting the flag gives the same result
    # and keeps the command shorter.
    if verbose:
        cmd.append("--verbose=yes")

    # User extras (last so they can override anything above)
    cmd.extend(extra_args)

    # Positional 1: optional blank_video (spec template)
    if blank_video is not None:
        cmd.append(str(blank_video))

    # Positional(s): audio files.
    #
    # Two modes:
    #   1. Single titleset: pass `audio_files` as a flat list (the default).
    #   2. Multi-titleset: pass `titleset_groups` as a list of lists. The `ts`
    #      flag is inserted between groups so lplex starts a new titleset for
    #      each album. This is how to put multiple albums on one DVD.
    if titleset_groups is not None:
        # Multi-titleset mode: interleave files with `ts` flags
        if not titleset_groups:
            raise MuxError("titleset_groups is empty — no audio files to process")
        for i, group in enumerate(titleset_groups):
            if i > 0:
                cmd.append("ts")  # start a new titleset for this album
            if not group:
                raise MuxError(f"titleset_groups[{i}] is empty — no audio files")
            for af in group:
                cmd.append(str(af))
    else:
        # Single-titleset mode: flat list of audio files
        if not audio_files:
            raise MuxError("No audio files provided to lplex")
        for af in audio_files:
            cmd.append(str(af))

    return cmd


def mux_album_with_lplex(
    album_name: str,
    output_dir: Path,
    audio_files: Sequence[Path],
    *,
    log_file: Optional[Path] = None,
    dry_run: bool = False,
    **lplex_kwargs: Any,
) -> Path:
    """
    Run lplex via wine to mux a single album, then build the final .iso.

    Two-stage pipeline (now that lplex's own ISO stage is broken in Wine):

      Stage 1 — lplex (via Wine) runs with `-c dvd` (the default):
        Creates the DVD-Video fileset (VIDEO_TS folder) via lplex's bundled
        dvdauthor.exe, which DOES work under Wine. Stops short of the ISO
        step (lplex's bundled mkisofs.exe fails under Wine with the error
        "Z:\\app\\work\\lplex\\bin\\mkisofs.exe not supported on this system").

      Stage 2 — we build the ISO ourselves using `xorriso -as mkisofs`:
        Same tool we use for burning, in its mkisofs emulation mode. See
        create_iso_from_video_ts(). The command mirrors lplex's own
        util/mkisofs.bat:
            xorriso -as mkisofs -dvd-video -V <volid> -udf -o <iso> <dvd_dir>

    If the caller passes create="iso" (overriding the default "dvd"),
    Stage 2 is skipped and we look for an .iso produced by lplex directly
    (the original pre-Wine-failure behaviour; mostly useful for debugging).

    Returns the path to the generated .iso.

    Raises MuxError if:
      * lplex.exe / wine binary missing
      * lplex exits non-zero
      * no VIDEO_TS folder is produced (when create="dvd", the default)
      * no .iso is produced (when create="iso")
      * xorriso fails or doesn't produce an .iso

    If dry_run=True, returns a synthetic iso path and does NOT execute
    Wine or xorriso.
    """
    # CRITICAL: resolve output_dir to an ABSOLUTE path before doing anything
    # else. lplex.exe is a Windows program running under Wine; when it sees
    # a relative path like "toilet2" passed via -d, it interprets it as a
    # Windows-style absolute path from the root of the Z: drive (which maps
    # to the Linux root /). So `-d toilet2` would write to /toilet2/ instead
    # of <CWD>/toilet2/. Resolving to absolute first means lplex sees
    # /abs/path/to/toilet2 and writes to /abs/path/to/toilet2/ correctly.
    # This also matches how audio file paths work (they're absolute via
    # _find_audio_files_in_dir or via user-supplied absolute paths).
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Validate inputs (filesystem checks live here, not in the pure
    # command-builder build_lplex_command()).
    audio_files = [Path(p) for p in audio_files]
    for af in audio_files:
        if not af.is_file():
            raise MuxError(f"Audio file not found: {af}")

    # Multi-titleset mode: if titleset_groups is provided, validate all files
    titleset_groups = lplex_kwargs.pop("titleset_groups", None)
    if titleset_groups is not None:
        for i, group in enumerate(titleset_groups):
            for af in group:
                if not Path(af).is_file():
                    raise MuxError(f"Audio file not found (titleset {i}): {af}")

    bg_image = lplex_kwargs.get("bg_image")
    if bg_image is not None:
        bg_image = Path(bg_image)
        if not bg_image.is_file():
            raise MuxError(f"Background image not found: {bg_image}")
        lplex_kwargs["bg_image"] = bg_image

    blank_video = lplex_kwargs.get("blank_video")
    if blank_video is not None:
        blank_video = Path(blank_video)
        if not blank_video.is_file():
            raise MuxError(f"Blank video file not found: {blank_video}")
        lplex_kwargs["blank_video"] = blank_video

    create_stage = lplex_kwargs.get("create", "dvd")

    cmd = build_lplex_command(
        album_name=album_name,
        output_dir=output_dir,
        audio_files=audio_files,
        titleset_groups=titleset_groups,
        **lplex_kwargs,
    )

    pretty_cmd = " ".join(shlex.quote(c) for c in cmd)
    log.info("lplex cmd: %s", pretty_cmd)

    # Sanitized ISO filename: replaces spaces and non-ASCII chars so the
    # resulting path is CLI-friendly (no shell quoting needed) and portable
    # across filesystems. The original album name is preserved as the DVD
    # volume label inside the ISO (via _sanitize_volume_label).
    safe_iso_stem = _sanitize_iso_filename(album_name)
    iso_path = output_dir / f"{safe_iso_stem}.iso"
    if dry_run:
        log.info("[dry-run] would run lplex with -c %s", create_stage)
        if create_stage == "dvd":
            log.info("[dry-run] would then build the ISO from the VIDEO_TS "
                     "folder lplex produces, output -> %s", iso_path)
        else:
            log.info("[dry-run] lplex would produce the .iso directly at %s",
                     iso_path)
        return iso_path

    # Verify the toolchain exists before we burn cycles on a Wine failure
    wine_bin = shutil.which(WINE_CMD)
    if wine_bin is None:
        raise MuxError(
            f"Wine binary '{WINE_CMD}' not found in PATH. "
            f"Phase 1 cannot run on the host without Wine; this script is "
            f"designed to run inside the Phase 0/3 Docker container."
        )
    if not LPLEX_PATH.is_file():
        raise MuxError(
            f"lplex.exe not found at {LPLEX_PATH}. "
            f"Override via LPLEX_PATH env var or --lplex-path CLI flag."
        )

    # --- Run lplex via Wine ---
    #
    # CRITICAL: lplex (a Windows C program running under Wine) uses stdio
    # buffering. When its stdout is connected to a PIPE, the C runtime
    # switches to FULL buffering (4KB+ chunks) — so lplex's INFO output
    # sits in the buffer and doesn't reach our log file until the buffer
    # fills or lplex exits. This makes the web UI's live log appear empty
    # (only the version banner, which lplex flushes explicitly, appears).
    #
    # Fix: use a pseudo-terminal (pty) instead of a pipe. A pty makes lplex
    # think it's writing to a real terminal, so the C runtime uses LINE
    # buffering — each line is flushed immediately. This gives us real-time
    # log output in the web UI.
    #
    # Both stdout and stderr go to the same pty (merged). We still filter
    # Wine noise by checking each line against _WINE_NOISE_PATTERNS.
    #
    # For CLI passthrough mode (log_file=None), we don't need the pty — the
    # user's terminal handles line buffering naturally.
    wine_env = _get_wine_env()

    if log_file:
        # Web app mode: use a pty so lplex line-buffers its output.
        import pty as _pty
        import select as _select

        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_fh = open(log_file, "w", encoding="utf-8")

        # Create a pseudo-terminal
        master_fd, slave_fd = _pty.openpty()

        try:
            try:
                proc = subprocess.Popen(
                    cmd,
                    stdout=slave_fd,
                    stderr=slave_fd,
                    stdin=subprocess.DEVNULL,
                    env=wine_env,
                    close_fds=True,
                )
            except OSError as exc:
                raise MuxError(f"Failed to launch wine: {exc}") from exc
            finally:
                # Close the slave fd in the parent process — the child has
                # its own copy. If we keep it open, read() on master_fd
                # won't return EOF when the child exits.
                os.close(slave_fd)

            # Read from the master fd, filter Wine noise, write to log file.
            # We use select() with a 1-second timeout so we can check if the
            # process has exited (and drain remaining output).
            while True:
                # Check if there's data to read
                ready, _, _ = _select.select([master_fd], [], [], 1.0)

                if ready:
                    try:
                        data = os.read(master_fd, 65536)
                    except OSError:
                        # EIO on pty master means the slave was closed (child exited)
                        break
                    if not data:
                        break
                    # Decode and filter line by line
                    text = data.decode("utf-8", errors="replace")
                    for line in text.splitlines(keepends=True):
                        stripped = line.rstrip("\r\n")
                        if stripped and _is_wine_noise_line(stripped):
                            continue  # drop Wine noise
                        log_fh.write(line)
                        log_fh.flush()

                # Check if the process has exited
                if proc.poll() is not None:
                    # Drain any remaining output (with a short timeout)
                    while True:
                        ready, _, _ = _select.select([master_fd], [], [], 0.1)
                        if not ready:
                            break
                        try:
                            data = os.read(master_fd, 65536)
                        except OSError:
                            break
                        if not data:
                            break
                        text = data.decode("utf-8", errors="replace")
                        for line in text.splitlines(keepends=True):
                            stripped = line.rstrip("\r\n")
                            if stripped and _is_wine_noise_line(stripped):
                                continue
                            log_fh.write(line)
                            log_fh.flush()
                    break

            proc.wait()
        finally:
            log_fh.close()
            try:
                os.close(master_fd)
            except OSError:
                pass
    else:
        # CLI passthrough mode: inherit the parent's stdio (user sees lplex
        # output on their terminal in real time). Still set the Wine env vars
        # to suppress noise on the terminal.
        try:
            proc = subprocess.run(
                cmd,
                stdout=None,  # inherit
                stderr=None,  # inherit
                text=True,
                check=False,
                env=wine_env,
            )
        except OSError as exc:
            raise MuxError(f"Failed to launch wine: {exc}") from exc

    if proc.returncode != 0:
        # Capture stderr if we didn't redirect
        err_tail = ""
        if log_file and log_file.is_file():
            err_tail = log_file.read_text(errors="replace")[-2000:]
        raise MuxError(
            f"lplex exited {proc.returncode} for album '{album_name}'. "
            f"Tail of log:\n{err_tail}"
        )

    # --- Stage 2: build the ISO ourselves if lplex only made VIDEO_TS -----
    if create_stage == "dvd":
        # Find the VIDEO_TS folder lplex produced
        dvd_folder = _find_video_ts_folder(output_dir)
        if dvd_folder is None:
            # Include the lplex log content in the error message so the
            # user can see why lplex failed to produce VIDEO_TS. lplex
            # sometimes exits with code 0 but doesn't produce any output
            # (e.g. when it can't find files or encounters an internal
            # error). The log content helps diagnose the issue.
            log_tail = ""
            if log_file and Path(log_file).is_file():
                log_tail = Path(log_file).read_text(errors="replace")[-3000:]
            elif not log_file:
                log_tail = "(lplex output went to console, not a log file)"
            raise MuxError(
                f"lplex reported success (exit 0) with -c dvd but no VIDEO_TS "
                f"folder was produced under {output_dir}.\n\n"
                f"--- lplex log (last 3000 chars) ---\n{log_tail}\n"
                f"--- end lplex log ---\n"
                f"If the log shows only lplex's version banner, lplex likely "
                f"couldn't find or process the audio files. Check that:\n"
                f"  1. The audio files exist at the paths shown in 'lplex cmd'\n"
                f"  2. The audio files are .wav or .flac (lplex only accepts these)\n"
                f"  3. The audio files meet DVD-Video specs (16/24-bit, 48/96kHz)\n"
                f"  4. The output directory is writable\n"
                f"  5. lplex's data/ folder (black backgrounds) is present"
            )
        log.info(
            "lplex produced VIDEO_TS at: %s — building ISO from it",
            dvd_folder / "VIDEO_TS",
        )
        return create_iso_from_video_ts(
            dvd_folder=dvd_folder,
            iso_path=iso_path,
            volume_label=album_name,
        )

    # Legacy path: lplex was asked to make the ISO directly (create="iso").
    # Look for the produced .iso file.
    isos = sorted(output_dir.glob("*.iso"))
    if not isos:
        raise MuxError(
            f"lplex reported success with -c iso but no .iso file was "
            f"produced in {output_dir}. Note: lplex's bundled mkisofs.exe "
            f"does NOT work under Wine — use the default -c dvd (we then "
            f"build the ISO ourselves with xorriso -as mkisofs)."
        )
    if len(isos) > 1:
        log.warning(
            "Multiple .iso files found in %s - using the newest: %s",
            output_dir, isos[-1].name,
        )
    iso_path = isos[-1]
    log.info("ISO produced: %s (%d bytes)", iso_path, iso_path.stat().st_size)
    return iso_path


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


def _find_audio_files_in_dir(album_dir: Path) -> List[Path]:
    """Discover audio files (.wav/.flac) in an album directory, sorted."""
    files = [
        p for p in sorted(album_dir.iterdir())
        if p.is_file() and p.suffix.lower() in SUPPORTED_AUDIO_EXT
    ]
    return files


# ---------------------------------------------------------------------------
# Album metadata extraction (ffprobe-based)
# ---------------------------------------------------------------------------


def fetch_album_metadata(album_dir: Path) -> dict:
    """Extract album metadata from audio files using ffprobe.

    Reads Vorbis comments (FLAC) and RIFF INFO tags (WAV) to build a
    metadata dict. Falls back gracefully — if tags are missing, the field
    is None (not an error).

    Returns:
        {
            "album_title": str | None,   # e.g. "An Awesome Wave"
            "artist": str | None,        # e.g. "alt-J"
            "year": str | None,          # e.g. "2012"
            "genre": str | None,
            "track_count": int,          # number of audio files
            "total_duration_sec": float, # sum of all track durations
            "files": [                   # per-file metadata
                {"filename": str, "title": str|None, "duration_sec": float,
                 "bit_depth": int|None, "sample_rate": int|None,
                 "channels": int|None, "codec": str|None}
            ]
        }
    """
    album_dir = Path(album_dir)
    if not album_dir.is_dir():
        return {
            "album_title": None, "artist": None, "year": None,
            "genre": None, "track_count": 0, "total_duration_sec": 0.0,
            "files": [],
        }

    audio_files = _find_audio_files_in_dir(album_dir)
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        # No ffprobe — return basic info without tags
        return {
            "album_title": None, "artist": None, "year": None,
            "genre": None, "track_count": len(audio_files),
            "total_duration_sec": 0.0, "files": [],
        }

    album_title = None
    artist = None
    year = None
    genre = None
    total_duration = 0.0
    files_meta = []

    for af in audio_files:
        cmd = [
            ffprobe, "-v", "error", "-print_format", "json",
            "-show_format", "-show_streams", str(af),
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  check=False)
        except OSError:
            continue
        if proc.returncode != 0:
            continue
        try:
            info = json.loads(proc.stdout)
        except json.JSONDecodeError:
            continue

        fmt = info.get("format", {}) or {}
        tags = fmt.get("tags", {}) or {}
        streams = info.get("streams", []) or []
        audio_streams = [s for s in streams if s.get("codec_type") == "audio"]
        s = audio_streams[0] if audio_streams else {}

        # Extract tags — Vorbis comments (FLAC) use uppercase, RIFF (WAV) uses different keys
        file_album = (tags.get("ALBUM") or tags.get("album")
                      or tags.get("INAM") or tags.get("title"))
        file_artist = (tags.get("ARTIST") or tags.get("artist")
                       or tags.get("IART") or tags.get("author"))
        file_year = (tags.get("DATE") or tags.get("date")
                     or tags.get("YEAR") or tags.get("year")
                     or tags.get("ICRD"))
        file_genre = (tags.get("GENRE") or tags.get("genre")
                      or tags.get("IGNR"))
        file_title = (tags.get("TITLE") or tags.get("title")
                      or tags.get("track_name"))

        # Use the first non-None value we find across all files
        if album_title is None and file_album:
            album_title = file_album
        if artist is None and file_artist:
            artist = file_artist
        if year is None and file_year:
            year = file_year
        if genre is None and file_genre:
            genre = file_genre

        duration = 0.0
        try:
            duration = float(fmt.get("duration") or 0)
        except (TypeError, ValueError):
            pass
        total_duration += duration

        def _to_int(v):
            if v is None: return None
            try: return int(v)
            except (TypeError, ValueError): return None

        files_meta.append({
            "filename": af.name,
            "title": file_title,
            "duration_sec": duration,
            "bit_depth": _to_int(s.get("bits_per_sample")
                                 or s.get("bits_per_raw_sample")),
            "sample_rate": _to_int(s.get("sample_rate")),
            "channels": _to_int(s.get("channels")),
            "codec": s.get("codec_name"),
        })

    return {
        "album_title": album_title,
        "artist": artist,
        "year": year,
        "genre": genre,
        "track_count": len(audio_files),
        "total_duration_sec": total_duration,
        "files": files_meta,
    }


def process_album(
    album_dir: Path,
    output_dir: Path,
    *,
    burn: bool = False,
    device: str = DVD_DEVICE,
    auto_eject: bool = True,
    poll_interval_sec: int = DEFAULT_POLL_INTERVAL_SEC,
    burn_wait_sec: int = DEFAULT_BURN_WAIT_SEC,
    burn_speed: int = 4,
    cleanup_intermediate: bool = False,
    dry_run: bool = False,
    log_file: Optional[Path] = None,
    **lplex_kwargs: Any,
) -> Path:
    """
    End-to-end orchestrator for one album.

    Steps:
      1. (optional) eject tray on `device` - "remote garage" workflow
         so the user can insert a disc while the ISO generates.
      2. Discover audio files in `album_dir`.
      3. probe_audio() + prepare_audio() each file into a staging subdir
         of `output_dir` (24-bit/48kHz/2ch WAV, or pass-through).
      4. mux_album_with_lplex() -> .iso in `output_dir`.
      5. (optional) poll_drive_ready() -> burn_iso().

    Returns the .iso Path on success.

    The orchestrator is drive-agnostic: if no optical drive is present
    (or `burn=False`), steps 1 and 5 are skipped or no-op, and the .iso
    remains in `output_dir` for the user to retrieve.

    If `dry_run=True`, audio files are NOT prepared (we just probe them)
    and lplex is invoked in dry-run mode (command printed, no Wine call).

    `log_file`: optional Path to capture lplex's stdout+stderr. Defaults to
    None (passthrough to the parent's console). The FastAPI web app passes
    a job-specific path so the web UI can stream lplex output via SSE.
    """
    album_dir = Path(album_dir).resolve()
    # Resolve output_dir to absolute so lplex gets an absolute path (relative
    # paths get misinterpreted by Wine as Z:\root paths). See mux_album_with_lplex
    # for the full explanation.
    output_dir = Path(output_dir).resolve()
    if not album_dir.is_dir():
        raise PipelineError(f"Album directory not found: {album_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)

    album_name = album_dir.name
    log.info("=== Processing album: %s ===", album_name)

    # Step 1: optional tray eject (drive-agnostic)
    if burn and auto_eject:
        drives = detect_optical_drives()
        if drives:
            log.info(
                "Optical drive(s) detected: %s",
                ", ".join(d.device for d in drives),
            )
            eject_tray(device)
        else:
            log.info("No optical drive detected - skipping eject (drive-agnostic mode)")

    # Step 2: discover audio files
    audio_files = _find_audio_files_in_dir(album_dir)
    if not audio_files:
        raise PrepareError(
            f"No .wav/.flac files found in album dir: {album_dir}"
        )
    log.info("Found %d audio file(s) in %s", len(audio_files), album_dir)

    # Step 3: probe + prepare each
    # NOTE: staging dir is a SIBLING of output_dir, NOT a child. If it's inside
    # output_dir, lplex's --cleanup=yes default tries to delete files inside
    # output_dir that it didn't create (our transcoded audio), producing
    # "*ERR: Unable to remove" messages. We now also pass -C no to lplex, but
    # keeping staging outside output_dir is defense-in-depth.
    staging = output_dir.parent / f"_staging_{album_name}"
    staging.mkdir(parents=True, exist_ok=True)
    prepared: List[Path] = []
    try:
        for af in audio_files:
            probe = probe_audio(af)
            log.info("  probe: %s", probe)
            if dry_run:
                # In dry-run we skip the actual transcode. For compliant
                # pass-through files with non-ASCII names, we still create
                # the symlink (it's a staging artifact, not a modification
                # of the original) so the lplex command shows the actual
                # path that would be used. For non-compliant files, we use
                # the original path (the transcode doesn't happen in dry-run).
                if (probe.compliant
                        and af.suffix.lower() in SUPPORTED_AUDIO_EXT):
                    safe_path = _safe_pass_through_path(af, staging)
                    prepared.append(safe_path)
                else:
                    prepared.append(af)
                continue
            out = prepare_audio(af, staging)
            # Pass-through path safety: if `prepare_audio()` returned the
            # ORIGINAL path (compliant pass-through) but the filename
            # contains non-ASCII characters that lplex/Wine can't handle
            # (e.g., the U+2010 Unicode HYPHEN, bytes \342\200\260 in
            # UTF-8, that some macOS tools auto-substitute), create a
            # symlink in the staging dir with a sanitized ASCII name
            # pointing at the original. We then pass the symlink path
            # (not the original) to lplex. The original file is never
            # modified.
            if out == af:
                # Compliant pass-through: check filename safety
                out = _safe_pass_through_path(out, staging)
            prepared.append(out)

        # Step 4: mux via lplex
        log.info("Muxing %d prepared file(s) via lplex...", len(prepared))
        # lplex stdout/stderr: passthrough to console by default (log_file=None
        # → subprocess.run inherits our stdio, the user sees real-time lplex
        # output). The FastAPI web app passes log_file=<job_dir>/lplex.log so
        # the web UI can stream lplex output via SSE.
        iso_path = mux_album_with_lplex(
            album_name=album_name,
            output_dir=output_dir,
            audio_files=prepared,
            log_file=log_file,
            dry_run=dry_run,
            **lplex_kwargs,
        )

        # Step 5: optional burn (drive-agnostic)
        if burn:
            drives = detect_optical_drives()
            if not drives:
                log.warning(
                    "Burn requested but no optical drive present. "
                    "ISO left at %s", iso_path,
                )
            else:
                log.info(
                    "Polling %s for ready disc (timeout %ds)...",
                    device, burn_wait_sec,
                )
                ready = poll_drive_ready(
                    device=device,
                    timeout_sec=burn_wait_sec,
                    poll_interval_sec=poll_interval_sec,
                )
                if ready:
                    if not dry_run:
                        burn_iso(iso_path, device=device, speed=burn_speed)
                    else:
                        log.info("[dry-run] would burn %s to %s", iso_path, device)
                else:
                    log.warning(
                        "Disc not ready within %ds - ISO left at %s",
                        burn_wait_sec, iso_path,
                    )
        return iso_path
    finally:
        if cleanup_intermediate and staging.exists():
            log.info("Cleaning up staging: %s", staging)
            shutil.rmtree(staging, ignore_errors=True)


def process_multi_album(
    album_dirs: Sequence[Path],
    output_dir: Path,
    *,
    project_name: Optional[str] = None,
    burn: bool = False,
    device: str = DVD_DEVICE,
    auto_eject: bool = True,
    poll_interval_sec: int = DEFAULT_POLL_INTERVAL_SEC,
    burn_wait_sec: int = DEFAULT_BURN_WAIT_SEC,
    burn_speed: int = 4,
    cleanup_intermediate: bool = False,
    dry_run: bool = False,
    log_file: Optional[Path] = None,
    **lplex_kwargs: Any,
) -> Path:
    """
    Process MULTIPLE albums into a SINGLE DVD with multiple titlesets.

    Each album becomes a separate title on the DVD, navigable via the DVD
    player's "next"/"prev" controls. This uses lplex's `ts` (titleset) flag
    to separate albums. All albums share the same DVD-Video structure
    (one VIDEO_TS folder, one ISO).

    Steps:
      1. (optional) eject tray
      2. For each album: discover + probe + prepare audio files
      3. Build a single lplex command with all files, inserting `ts` between
         albums
      4. Run lplex once → single VIDEO_TS with multiple titlesets
      5. Build the ISO from VIDEO_TS
      6. (optional) burn

    Args:
        album_dirs: list of album directory paths (each becomes one titleset)
        output_dir: where to write the ISO + VIDEO_TS
        project_name: the DVD/project name (defaults to a joined list of
            album names, sanitized). This becomes the DVD volume label.
        burn: if True and a drive is present, burn the ISO after generation
        log_file: optional path to capture lplex stdout+stderr (for the web UI)
        **lplex_kwargs: lplex options (media, create, alignment, shift, etc.)

    Returns the .iso Path on success.
    """
    # Resolve all paths to absolute (Wine Z: drive mapping issue)
    album_dirs = [Path(d).resolve() for d in album_dirs]
    output_dir = Path(output_dir).resolve()
    if not album_dirs:
        raise PipelineError("No album directories provided")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Derive project name from album names if not provided
    if project_name is None:
        names = [d.name for d in album_dirs]
        project_name = " + ".join(names) if len(names) <= 3 else f"{len(names)} albums"

    log.info("=== Processing multi-album DVD: %s ===", project_name)
    log.info("  Albums: %s", [d.name for d in album_dirs])

    # Step 1: optional tray eject
    if burn and auto_eject:
        drives = detect_optical_drives()
        if drives:
            eject_tray(device)

    # Step 2: discover + probe + prepare each album's files
    # NOTE: staging dir is a SIBLING of output_dir, NOT a child. See
    # process_album for the full explanation (lplex cleanup issue).
    staging = output_dir.parent / f"_staging_multi"
    staging.mkdir(parents=True, exist_ok=True)
    titleset_groups: List[List[Path]] = []
    try:
        for i, album_dir in enumerate(album_dirs, 1):
            if not album_dir.is_dir():
                raise PrepareError(f"Album directory not found: {album_dir}")
            audio_files = _find_audio_files_in_dir(album_dir)
            if not audio_files:
                raise PrepareError(
                    f"No .wav/.flac files found in album dir: {album_dir}"
                )
            log.info("[%d/%d] Album: %s (%d files)", i, len(album_dirs),
                     album_dir.name, len(audio_files))

            prepared: List[Path] = []
            for af in audio_files:
                probe = probe_audio(af)
                log.info("  probe: %s", probe)
                if dry_run:
                    if (probe.compliant
                            and af.suffix.lower() in SUPPORTED_AUDIO_EXT):
                        safe_path = _safe_pass_through_path(af, staging)
                        prepared.append(safe_path)
                    else:
                        prepared.append(af)
                    continue
                out = prepare_audio(af, staging)
                if out == af:
                    out = _safe_pass_through_path(out, staging)
                prepared.append(out)
            titleset_groups.append(prepared)

        # Step 3+4: build lplex command with ts flags and run
        log.info("Muxing %d titleset(s) via lplex...", len(titleset_groups))
        iso_path = mux_album_with_lplex(
            album_name=project_name,
            output_dir=output_dir,
            audio_files=[],  # empty; using titleset_groups instead
            titleset_groups=titleset_groups,
            log_file=log_file,
            dry_run=dry_run,
            **lplex_kwargs,
        )

        # Step 5: optional burn
        if burn:
            drives = detect_optical_drives()
            if not drives:
                log.warning("Burn requested but no optical drive present. ISO left at %s", iso_path)
            else:
                ready = poll_drive_ready(device, burn_wait_sec, poll_interval_sec)
                if ready and not dry_run:
                    burn_iso(iso_path, device=device, speed=burn_speed)
                elif ready and dry_run:
                    log.info("[dry-run] would burn %s to %s", iso_path, device)

        return iso_path
    finally:
        if cleanup_intermediate and staging.exists():
            log.info("Cleaning up staging: %s", staging)
            shutil.rmtree(staging, ignore_errors=True)


def batch_process(
    album_dirs: Sequence[Path],
    output_dir: Path,
    *,
    stop_on_error: bool = False,
    **kwargs: Any,
) -> List[Path]:
    """
    Process multiple albums sequentially. Returns list of .iso paths
    (one per album). Albums that failed are skipped (with a log error)
    unless `stop_on_error=True`, in which case the first failure raises.
    """
    isos: List[Path] = []
    for i, ad in enumerate(album_dirs, 1):
        log.info("[%d/%d] Album: %s", i, len(album_dirs), ad)
        try:
            iso = process_album(ad, output_dir, **kwargs)
            isos.append(iso)
        except PipelineError as exc:
            log.error("Album %s failed: %s", ad, exc)
            if stop_on_error:
                raise
    return isos


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _add_common_lplex_args(p: argparse.ArgumentParser) -> None:
    """Common lplex-related flags shared by `process` and `batch`."""
    p.add_argument(
        "--media", default="dvd-r",
        choices=["dvd-r", "dvd+r", "dl", "none"],
        help="lplex -z media target (default: dvd-r)",
    )
    p.add_argument(
        "--create", default="dvd",
        choices=["lpcm", "m2v", "dvdstyler", "mpeg", "dvd", "iso"],
        help="lplex -c create stage. Default 'dvd' stops at the VIDEO_TS "
             "folder (lplex's bundled mkisofs.exe doesn't work under Wine); "
             "we then build the ISO ourselves with xorriso -as mkisofs. "
             "Use 'iso' only if you want to let lplex try mkisofs.exe "
             "directly (will fail under Wine; mostly for debugging). "
             "Other values: 'lpcm' (just extract LPCM), 'm2v' (MPEG-2 "
             "video), 'mpeg' (muxed MPEG), 'dvdstyler' (DVDStyler project).",
    )
    p.add_argument(
        "--title-flag", default="name",
        choices=["name", "title"],
        help="lplex flag for the DVD title. lplex 0.3 uses --name; "
             "use --title only if your build differs.",
    )
    p.add_argument(
        "--lplex-format", default=None,
        help="Optional lplex -f value (not used by lplex 0.3 for muxing; "
             "kept for compatibility)",
    )
    p.add_argument(
        "--alignment", default="seamless",
        choices=["seamless", "discrete", "padded", "none"],
        help="lplex --splice / -l value (default: seamless = concert mode)",
    )
    p.add_argument(
        "--shift", default="backward",
        choices=["backward", "forward", "nearest"],
        help="lplex --shift / -s (only used when alignment=seamless)",
    )
    p.add_argument(
        "--tv-standard", default=None,
        choices=["pal", "ntsc"],
        help="lplex -t (pal/ntsc). If unset, lplex auto-detects.",
    )
    p.add_argument(
        "--blank-video", default=None, type=Path,
        help="Pass FILE as first positional (spec template). For lplex "
             "0.3 prefer --bg-image instead.",
    )
    p.add_argument(
        "--bg-image", default=None, type=Path,
        help="Custom background JPEG for lplex -j =<path>",
    )
    p.add_argument(
        "--bg-preset", default="black",
        help="lplex -j background preset (black, black_L, black_M, black_S, "
             "black_XS, or a custom path). Default: black",
    )
    p.add_argument(
        "--lplex-path", default=None, type=Path,
        help="Override lplex.exe path (defaults to LPLEX_PATH env or "
             "/app/work/lplex/lplex.exe)",
    )
    p.add_argument(
        "--verbose-lplex", action="store_true",
        help="Pass --verbose=yes to lplex",
    )


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="audio_dvd_burner",
        description="Lean Audio DVD Burner - Phase 1 core pipeline. "
                    "Probes audio, prepares (transcodes if needed), muxes "
                    "via Wine-wrapped lplex into a DVD-Video ISO, and "
                    "optionally burns to /dev/sr0.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  # Probe a single file
  %(prog)s probe /path/to/track.wav

  # Process one album into an ISO (no burn)
  %(prog)s process /path/to/album --output /data/output

  # Process one album, burn to disc (remote garage workflow)
  %(prog)s process /path/to/album --output /data/output --burn

  # Process multiple albums sequentially
  %(prog)s batch /path/to/album1 /path/to/album2 --output /data/output

  # Show optical drive status
  %(prog)s drive-status

  # Burn an existing ISO
  %(prog)s burn /data/output/myalbum.iso --device /dev/sr0
""",
    )
    p.add_argument("--log-level", default="INFO",
                   choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
    p.add_argument("--log-file", default=None, type=Path,
                   help="Optional log file (in addition to stderr)")

    sub = p.add_subparsers(dest="cmd", required=True, metavar="<command>")

    # probe
    p_probe = sub.add_parser(
        "probe", help="Probe audio file(s) with ffprobe (read-only)",
    )
    p_probe.add_argument("files", nargs="+", type=Path, help="Audio file(s)")

    # process
    p_proc = sub.add_parser(
        "process", help="Process one album dir -> ISO (+ optional burn)",
    )
    p_proc.add_argument("album_dir", type=Path, help="Album directory")
    p_proc.add_argument("--output", "-o", required=True, type=Path,
                        help="Output directory for ISO + logs")
    p_proc.add_argument("--burn", action="store_true",
                        help="Burn ISO to optical drive after mux")
    p_proc.add_argument("--device", default=DVD_DEVICE,
                        help=f"Optical device (default: {DVD_DEVICE})")
    p_proc.add_argument("--auto-eject", action="store_true", default=True,
                        help="Eject tray at job start (default: on with --burn)")
    p_proc.add_argument("--no-auto-eject", dest="auto_eject",
                        action="store_false",
                        help="Disable auto-eject at job start")
    p_proc.add_argument("--poll-interval", type=int,
                        default=DEFAULT_POLL_INTERVAL_SEC,
                        help=f"Drive poll interval sec (default: {DEFAULT_POLL_INTERVAL_SEC})")
    p_proc.add_argument("--burn-wait", type=int,
                        default=DEFAULT_BURN_WAIT_SEC,
                        help=f"Drive ready poll timeout sec (default: {DEFAULT_BURN_WAIT_SEC})")
    p_proc.add_argument("--burn-speed", type=int, default=4,
                        help="xorriso -speed (default: 4)")
    p_proc.add_argument("--cleanup-intermediate", action="store_true",
                        help="Remove _staging_<album> after mux")
    p_proc.add_argument("--dry-run", action="store_true",
                        help="Probe + print lplex cmd without executing Wine")
    _add_common_lplex_args(p_proc)

    # batch
    p_batch = sub.add_parser(
        "batch", help="Process multiple album dirs sequentially",
    )
    p_batch.add_argument("album_dirs", nargs="+", type=Path,
                          help="Album directories")
    p_batch.add_argument("--output", "-o", required=True, type=Path,
                         help="Output directory for ISOs + logs")
    p_batch.add_argument("--stop-on-error", action="store_true",
                         help="Re-raise on first failure (default: skip and continue)")
    p_batch.add_argument("--burn", action="store_true")
    p_batch.add_argument("--device", default=DVD_DEVICE)
    p_batch.add_argument("--no-auto-eject", dest="auto_eject",
                         action="store_false", default=True)
    p_batch.add_argument("--burn-wait", type=int, default=DEFAULT_BURN_WAIT_SEC)
    p_batch.add_argument("--poll-interval", type=int,
                          default=DEFAULT_POLL_INTERVAL_SEC)
    p_batch.add_argument("--burn-speed", type=int, default=4)
    p_batch.add_argument("--dry-run", action="store_true")
    p_batch.add_argument("--cleanup-intermediate", action="store_true")
    _add_common_lplex_args(p_batch)

    # drive-status
    p_ds = sub.add_parser(
        "drive-status", help="Print optical drive detection + media status",
    )
    p_ds.add_argument("--device", default=DVD_DEVICE,
                      help=f"Optical device (default: {DVD_DEVICE})")
    p_ds.add_argument("--json", action="store_true", help="Output JSON")

    # burn
    p_burn = sub.add_parser(
        "burn", help="Burn an existing .iso to optical drive",
    )
    p_burn.add_argument("iso", type=Path, help="ISO file to burn")
    p_burn.add_argument("--device", default=DVD_DEVICE,
                        help=f"Optical device (default: {DVD_DEVICE})")
    p_burn.add_argument("--speed", type=int, default=4,
                        help="xorriso -speed (default: 4)")
    p_burn.add_argument("--poll", action="store_true",
                        help="Poll drive for ready disc before burning")
    p_burn.add_argument("--poll-timeout", type=int,
                        default=DEFAULT_BURN_WAIT_SEC,
                        help="Poll timeout sec (default: %d)" % DEFAULT_BURN_WAIT_SEC)
    p_burn.add_argument("--poll-interval", type=int,
                        default=DEFAULT_POLL_INTERVAL_SEC,
                        help="Poll interval sec (default: %d)" % DEFAULT_POLL_INTERVAL_SEC)

    return p


def _configure_logging(level: str, log_file: Optional[Path]) -> None:
    handlers: List[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    fmt = "%(asctime)s %(levelname)-7s %(message)s"
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=fmt,
        handlers=handlers,
        force=True,
    )


def _handle_probe(args: argparse.Namespace) -> int:
    out: List[dict] = []
    for f in args.files:
        try:
            probe = probe_audio(f)
            print(probe)
            out.append(probe.as_dict())
        except ProbeError as exc:
            log.error("%s: %s", f, exc)
            out.append({"path": str(f), "error": str(exc)})
    # Always emit a final JSON blob to stderr for log parsing
    print("\n=== JSON ===", file=sys.stderr)
    print(json.dumps(out, indent=2), file=sys.stderr)
    # Exit 0 if all probed, 2 if any failed
    return 0 if all("error" not in o for o in out) else 2


def _handle_process(args: argparse.Namespace) -> int:
    lplex_kwargs = dict(
        media=args.media,
        create=args.create,
        title_flag=args.title_flag,
        lplex_format=args.lplex_format,
        alignment=args.alignment,
        shift=args.shift,
        tv_standard=args.tv_standard,
        blank_video=args.blank_video,
        bg_image=args.bg_image,
        bg_preset=args.bg_preset,
        verbose=args.verbose_lplex,
    )
    # Override LPLEX_PATH if --lplex-path given
    if args.lplex_path:
        global LPLEX_PATH
        LPLEX_PATH = args.lplex_path.resolve()
    try:
        iso = process_album(
            album_dir=args.album_dir,
            output_dir=args.output,
            burn=args.burn,
            device=args.device,
            auto_eject=args.auto_eject,
            poll_interval_sec=args.poll_interval,
            burn_wait_sec=args.burn_wait,
            burn_speed=args.burn_speed,
            cleanup_intermediate=args.cleanup_intermediate,
            dry_run=args.dry_run,
            **lplex_kwargs,
        )
        print(f"ISO: {iso}")
        return 0
    except PipelineError as exc:
        log.error("%s", exc)
        return exc.exit_code


def _handle_batch(args: argparse.Namespace) -> int:
    lplex_kwargs = dict(
        media=args.media,
        create=args.create,
        title_flag=args.title_flag,
        lplex_format=args.lplex_format,
        alignment=args.alignment,
        shift=args.shift,
        tv_standard=args.tv_standard,
        blank_video=args.blank_video,
        bg_image=args.bg_image,
        bg_preset=args.bg_preset,
        verbose=args.verbose_lplex,
    )
    if args.lplex_path:
        global LPLEX_PATH
        LPLEX_PATH = args.lplex_path.resolve()
    try:
        isos = batch_process(
            album_dirs=args.album_dirs,
            output_dir=args.output,
            stop_on_error=args.stop_on_error,
            burn=args.burn,
            device=args.device,
            auto_eject=args.auto_eject,
            poll_interval_sec=args.poll_interval,
            burn_wait_sec=args.burn_wait,
            burn_speed=args.burn_speed,
            cleanup_intermediate=args.cleanup_intermediate,
            dry_run=args.dry_run,
            **lplex_kwargs,
        )
        for iso in isos:
            print(f"ISO: {iso}")
        return 0 if isos else 1
    except PipelineError as exc:
        log.error("%s", exc)
        return exc.exit_code


def _handle_drive_status(args: argparse.Namespace) -> int:
    drives = detect_optical_drives()
    if args.json:
        out = {
            "drives": [d.as_dict() for d in drives],
            "selected_device": args.device,
            "status": drive_status(args.device),
        }
        print(json.dumps(out, indent=2))
    else:
        if not drives:
            print("No optical drives detected.")
        else:
            print(f"Optical drives ({len(drives)}):")
            for d in drives:
                print(f"  - {d.device}  {d.vendor} {d.model}  ({d.size_bytes/1e9:.1f} GB)")
        st = drive_status(args.device)
        print(f"\nSelected device: {st['device']}")
        print(f"  exists:      {st['exists']}")
        print(f"  has_disc:    {st['has_disc']}")
        print(f"  tray_state:  {st['tray_state']}")
    return 0


def _handle_burn(args: argparse.Namespace) -> int:
    drives = detect_optical_drives()
    if not drives:
        log.error("No optical drive detected.")
        return NoDriveError.exit_code
    if args.poll:
        if not poll_drive_ready(args.device, args.poll_timeout, args.poll_interval):
            log.error("Drive not ready within %ds", args.poll_timeout)
            return BurnError.exit_code
    try:
        burn_iso(args.iso, device=args.device, speed=args.speed)
        return 0
    except PipelineError as exc:
        log.error("%s", exc)
        return exc.exit_code


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    _configure_logging(args.log_level, args.log_file)

    handlers = {
        "probe": _handle_probe,
        "process": _handle_process,
        "batch": _handle_batch,
        "drive-status": _handle_drive_status,
        "burn": _handle_burn,
    }
    handler = handlers.get(args.cmd)
    if handler is None:
        parser.print_help(sys.stderr)
        return 64
    try:
        return handler(args)
    except KeyboardInterrupt:
        log.warning("Interrupted by user")
        return 130


if __name__ == "__main__":
    sys.exit(main())
